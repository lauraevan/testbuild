import SwiftUI
import UserNotifications
import UIKit

private enum SettingsRoute: String, Hashable {
    case profile = "Profile"
    case billing = "Billing"
    case usage = "Usage"
    case notifications = "Notifications"
    case focus = "Time & focus"
    case privacy = "Privacy"
    case sharedLinks = "Shared links"
    case capabilities = "Capabilities"
    case code = "Claude Code"
    case connections = "Connectors"
    case appearance = "Appearance"
    case personalization = "Personalization"
    case api = "API connection"
    case language = "Language"
    case help = "Help & support"
    case about = "About"
}

struct SettingsScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @State private var infoOpen = false
    @State private var accountOpen = false
    @AppStorage("claudere-display-name") private var displayName = "Personal"
    @AppStorage("claudere-profile-initial") private var profileInitial = "B"

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack {
                    RoundIconButton(symbol: "xmark") { store.navigate(.chat) }
                    Spacer()
                    Text("Settings")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(ClaudeColors.text(scheme))
                    Spacer()
                    RoundIconButton(symbol: "info") { infoOpen = true }
                }
                .padding(.horizontal, 16)
                .frame(height: 72)

                ScrollView {
                    VStack(alignment: .leading, spacing: 27) {
                        accountCard
                        section("Account") {
                            settingsRow("person.crop.circle", "Profile", .profile)
                            settingsRow("dollarsign.circle", "Billing", .billing, trailing: "API billing")
                            externalRow("arrow.up.circle", "Claude plans", url: "https://claude.com/pricing")
                            settingsRow("gauge.with.dots.needle.33percent", "Usage", .usage)
                            settingsRow("bell", "Notifications", .notifications)
                            settingsRow("moon.stars", "Time & focus", .focus)
                            settingsRow("checkmark.shield", "Privacy", .privacy)
                            settingsRow("link", "Shared links", .sharedLinks, divider: false)
                        }
                        section("App") {
                            settingsRow("slider.horizontal.3", "Capabilities", .capabilities)
                            settingsRow("chevron.left.forwardslash.chevron.right", "Claude Code", .code)
                            settingsRow("square.stack.3d.up", "Connectors", .connections)
                            settingsRow("paintpalette", "Appearance", .appearance)
                            settingsRow("person.text.rectangle", "Personalization", .personalization)
                            settingsRow("key.horizontal", "API connection", .api)
                            settingsRow("globe", "Language", .language, divider: false)
                        }
                        section("Support") {
                            settingsRow("questionmark.circle", "Help & support", .help)
                            settingsRow("info.circle", "About ClaudeFaithful", .about, divider: false)
                        }
                        Text("ClaudeFaithful is an independent, local-first frontend. Anthropic accounts, plan status, usage, and connected services do not sync to this app.")
                            .font(.system(size: 11.5))
                            .foregroundStyle(ClaudeColors.muted(scheme))
                            .padding(.horizontal, 25)
                            .padding(.bottom, 36)
                    }
                    .padding(.horizontal, 19)
                    .padding(.top, 17)
                }
                .scrollIndicators(.hidden)
            }
            .background(ClaudeColors.background(scheme).ignoresSafeArea())
            .toolbar(.hidden, for: .navigationBar)
            .navigationDestination(for: SettingsRoute.self) { route in
                SettingsDetailScreen(route: route)
            }
        }
        .sheet(isPresented: $infoOpen) {
            VStack(spacing: 19) {
                SheetHandle()
                ClaudeMark(size: 45)
                Text("About this app").font(.system(size: 24, weight: .semibold, design: .serif))
                Text("An independent native recreation built in SwiftUI. Your conversations and projects are stored on this device. Live chat needs an Anthropic API key; a Claude Pro subscription does not automatically work here.")
                    .font(.system(size: 15)).multilineTextAlignment(.center)
                    .foregroundStyle(ClaudeColors.muted(scheme))
                Button("Got it") { infoOpen = false }
                    .buttonStyle(.borderedProminent).tint(ClaudeColors.accent)
            }
            .padding(25)
            .presentationDetents([.medium])
        }
        .sheet(isPresented: $accountOpen) {
            NavigationStack {
                VStack(spacing: 14) {
                    Image(systemName: "person.crop.circle.badge.plus")
                        .font(.system(size: 43)).foregroundStyle(ClaudeColors.accent)
                    Text("Connect your own API key").font(.system(size: 22, weight: .semibold))
                    Text("Anthropic account sign-in and account switching require Anthropic's own authentication service. Use an API key in Settings → API connection for live messages instead.")
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                    NavigationLink("Open API settings", value: SettingsRoute.api)
                        .buttonStyle(.borderedProminent)
                        .tint(ClaudeColors.accent)
                }
                .padding(25)
                .navigationTitle("Account")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { accountOpen = false } } }
                .navigationDestination(for: SettingsRoute.self) { SettingsDetailScreen(route: $0) }
            }
            .presentationDetents([.medium, .large])
        }
    }

    private var accountCard: some View {
        VStack(spacing: 0) {
            HStack(spacing: 13) {
                Text(profileInitial.isEmpty ? "B" : String(profileInitial.prefix(1)).uppercased())
                    .font(.system(size: 17, weight: .medium))
                    .foregroundStyle(.white)
                    .frame(width: 44, height: 44)
                    .background(Color.black, in: Circle())
                VStack(alignment: .leading, spacing: 5) {
                    Text(displayName.isEmpty ? "Personal" : displayName)
                        .font(.system(size: 17, weight: .medium))
                        .foregroundStyle(ClaudeColors.text(scheme))
                    Text(APIKeyVault.read() == nil ? "Local profile · Demo" : "Local profile · API connected")
                        .font(.system(size: 13))
                        .foregroundStyle(ClaudeColors.muted(scheme))
                }
                Spacer()
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(14)
            Rectangle().fill(ClaudeColors.stroke(scheme)).frame(height: 1).padding(.leading, 18)
            Button { accountOpen = true } label: {
                HStack(spacing: 16) {
                    Image(systemName: "plus")
                        .font(.system(size: 21, weight: .light)).frame(width: 28)
                    Text("Add account")
                    Spacer()
                }
                .font(.system(size: 16))
                .foregroundStyle(ClaudeColors.brightBlue)
                .padding(.horizontal, 24)
                .frame(height: 54)
            }
        }
        .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 25))
    }

    private func section<Content: View>(_ name: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 11) {
            Text(name)
                .font(.system(size: 15))
                .foregroundStyle(ClaudeColors.muted(scheme))
                .padding(.leading, 19)
            VStack(spacing: 0, content: content)
                .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 24))
        }
    }

    private func settingsRow(_ symbol: String, _ text: String, _ route: SettingsRoute, trailing: String? = nil, divider: Bool = true) -> some View {
        VStack(spacing: 0) {
            NavigationLink(value: route) {
                HStack(spacing: 15) {
                    Image(systemName: symbol)
                        .font(.system(size: 18, weight: .regular))
                        .frame(width: 27)
                        .foregroundStyle(ClaudeColors.text(scheme).opacity(0.83))
                    Text(text).font(.system(size: 17)).foregroundStyle(ClaudeColors.text(scheme))
                    Spacer(minLength: 6)
                    if let trailing {
                        Text(trailing).font(.system(size: 13)).foregroundStyle(ClaudeColors.muted(scheme))
                    }
                    Image(systemName: "chevron.right")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(ClaudeColors.muted(scheme).opacity(0.7))
                }
                .padding(.horizontal, 22)
                .frame(height: 52)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if divider { Rectangle().fill(ClaudeColors.stroke(scheme)).frame(height: 1).padding(.leading, 70).padding(.trailing, 19) }
        }
    }

    private func externalRow(_ symbol: String, _ text: String, url: String) -> some View {
        VStack(spacing: 0) {
            Link(destination: URL(string: url)!) {
                HStack(spacing: 15) {
                    Image(systemName: symbol).font(.system(size: 18)).frame(width: 27)
                    Text(text).font(.system(size: 17))
                    Spacer()
                    Image(systemName: "arrow.up.right").font(.system(size: 13)).foregroundStyle(ClaudeColors.muted(scheme))
                }
                .foregroundStyle(ClaudeColors.text(scheme))
                .padding(.horizontal, 22).frame(height: 52)
            }
            Rectangle().fill(ClaudeColors.stroke(scheme)).frame(height: 1).padding(.leading, 70).padding(.trailing, 19)
        }
    }
}

private struct SettingsDetailScreen: View {
    let route: SettingsRoute
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @AppStorage("claudere-appearance") private var appearance = "Dark"
    @AppStorage("claudere-display-name") private var displayName = "Personal"
    @AppStorage("claudere-profile-initial") private var initial = "B"
    @AppStorage("claudere-writing-style") private var style = "Normal"
    @AppStorage("claudere-personal-instructions") private var personalInstructions = ""
    @AppStorage("claudere-memory") private var memory = ""
    @AppStorage("claudere-notifications") private var notifications = false
    @AppStorage("claudere-focus") private var focus = false
    @AppStorage("claudere-focus-start") private var focusStart = "22:00"
    @AppStorage("claudere-focus-end") private var focusEnd = "07:00"
    @AppStorage("claudere-default-incognito") private var defaultIncognito = false
    @AppStorage("claudere-save-chats") private var saveChats = true
    @AppStorage("claudere-reading-size") private var readingSize = 18.0
    @State private var apiKeyInput = ""
    @State private var hasKey = APIKeyVault.read() != nil
    @State private var showKey = false
    @State private var deleteAlert = false
    @State private var alertMessage: String?

    private var exportedHistory: String {
        store.sortedConversations.map { conversation in
            "# \(conversation.title)\n\n" + conversation.messages.map { "\($0.role == .user ? "You" : "Assistant"): \($0.text)" }.joined(separator: "\n\n")
        }.joined(separator: "\n\n---\n\n")
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 19) {
                detailContent
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(21)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(ClaudeColors.background(scheme).ignoresSafeArea())
        .navigationTitle(route.rawValue)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar(.visible, for: .navigationBar)
        .toolbarBackground(ClaudeColors.background(scheme), for: .navigationBar)
        .alert("Notice", isPresented: Binding(get: { alertMessage != nil }, set: { if !$0 { alertMessage = nil } })) {
            Button("OK", role: .cancel) { alertMessage = nil }
        } message: { Text(alertMessage ?? "") }
        .confirmationDialog("Delete all local conversations?", isPresented: $deleteAlert) {
            Button("Delete conversations", role: .destructive) {
                store.conversations.removeAll(); store.persist(); store.newChat()
            }
        } message: { Text("This only affects this device. This cannot be undone.") }
    }

    @ViewBuilder private var detailContent: some View {
        switch route {
        case .profile:
            detailNote("This local profile is not linked to your Anthropic account.")
            group {
                labeledField("Display name", text: $displayName)
                labeledField("Avatar initial", text: $initial)
            }
            detailNote("Appearance and profile details are kept on this iPhone.")
        case .billing:
            featured("Billing", "Your Claude subscription is separate from API billing.", symbol: "creditcard")
            settingLink("Manage API billing", url: "https://platform.claude.com/settings/billing")
            settingLink("Claude subscription plans", url: "https://claude.com/pricing")
        case .usage:
            featured("Local activity", "Only usage inside this recreation is shown here, not Claude account limits.", symbol: "chart.bar")
            group {
                metric("Conversations", value: "\(store.conversations.count)")
                divider
                metric("Messages", value: "\(store.conversations.reduce(0) { $0 + $1.messages.count })")
                divider
                metric("Projects", value: "\(store.projects.count)")
            }
            settingLink("Check official API usage", url: "https://platform.claude.com/settings/usage")
        case .notifications:
            featured("Notifications", "Grant permission for reminders scheduled locally in this app.", symbol: "bell")
            group {
                Toggle("Local reminders", isOn: $notifications)
                    .onChange(of: notifications) { _, value in
                        if value { UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { allowed, _ in
                            if !allowed { DispatchQueue.main.async { notifications = false } }
                        } }
                    }.padding(17)
            }
            detailNote("This does not receive notifications from Anthropic or synchronize Claude tasks.")
        case .focus:
            featured("Time & focus", "Limit local reminder interruptions during your quiet hours.", symbol: "moon.stars")
            group {
                Toggle("Quiet hours", isOn: $focus).padding(17)
                divider
                labeledField("Start (24h)", text: $focusStart)
                labeledField("End (24h)", text: $focusEnd)
            }
            detailNote("Example: 22:00 to 07:00. Quiet hours apply to local reminders created within this app.")
        case .privacy:
            featured("Privacy", "Chat history stays on your device unless you send messages through the Anthropic API.", symbol: "lock.shield")
            group {
                Toggle("Start chats in incognito mode", isOn: $defaultIncognito).padding(17)
                divider
                Toggle("Save new conversations locally", isOn: $saveChats).padding(17)
            }
            ShareLink(item: exportedHistory.isEmpty ? "No local conversations" : exportedHistory) {
                HStack { Label("Export local chat history", systemImage: "square.and.arrow.up"); Spacer(); Image(systemName: "chevron.right") }
                    .padding(17).foregroundStyle(ClaudeColors.text(scheme))
                    .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 17))
            }
            Button(role: .destructive) { deleteAlert = true } label: {
                Label("Delete all local conversations", systemImage: "trash")
                    .frame(maxWidth: .infinity, alignment: .leading).padding(17)
                    .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 17))
            }
        case .sharedLinks:
            featured("Shared conversations", "Export or share transcripts using the iOS share sheet. These are not publicly hosted Claude share links.", symbol: "link")
            if store.conversations.isEmpty { detailNote("Your conversations will appear here after you start chatting.") }
            ForEach(store.sortedConversations) { conversation in
                ShareLink(item: conversation.messages.map { "\($0.role == .user ? "You" : "Assistant"): \($0.text)" }.joined(separator: "\n\n")) {
                    HStack {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(conversation.title).font(.system(size: 15, weight: .semibold))
                            Text("Share transcript").font(.system(size: 12)).foregroundStyle(.secondary)
                        }
                        Spacer(); Image(systemName: "square.and.arrow.up")
                    }
                    .padding(16)
                    .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 16))
                }
                .foregroundStyle(ClaudeColors.text(scheme))
            }
        case .capabilities:
            featured("Capabilities", "Choose the available tools for live API messages.", symbol: "slider.horizontal.3")
            group {
                Toggle("Adaptive thinking", isOn: $store.thinkEnabled).padding(17)
                divider
                Toggle("Web search", isOn: $store.webSearchEnabled).padding(17)
            }
            detailNote("Adaptive thinking and web search use Anthropic API features. Some tools may require access or incur API charges. Computer use and connected apps require additional infrastructure.")
            NavigationLink(value: SettingsRoute.api) { Label("Configure API", systemImage: "key").foregroundStyle(ClaudeColors.accent) }.padding(9)
        case .code:
            featured("Claude Code", "Run Claude Code on your Mac or PC using Anthropic's official tooling.", symbol: "terminal")
            group {
                HStack { Text("Install command").font(.system(size: 13)); Spacer(); Button("Copy") { UIPasteboard.general.string = "npm install -g @anthropic-ai/claude-code" } }
                    .padding(17)
                divider
                Text("npm install -g @anthropic-ai/claude-code")
                    .font(.system(size: 12, design: .monospaced)).textSelection(.enabled).padding(17)
            }
            settingLink("Claude Code documentation", url: "https://code.claude.com/docs/en/overview")
            detailNote("The replica cannot connect to an existing Claude Code session or control your computer without a separately configured service.")
        case .connections:
            featured("Connectors", "Linking Gmail, Drive, Calendar, and desktop apps requires provider authorization and supported backend integrations.", symbol: "square.stack.3d.up")
            group {
                connector("envelope", "Gmail", "Not connected")
                divider
                connector("folder", "Google Drive", "Not connected")
                divider
                connector("calendar", "Google Calendar", "Not connected")
                divider
                connector("desktopcomputer", "Desktop and computer use", "Not connected")
            }
            detailNote("These rows are informational, not fake sign-in flows. Local file and image attachments are available through the chat composer.")
        case .appearance:
            featured("Appearance", "Customize the look and reading size of your app.", symbol: "paintpalette")
            group {
                Picker("Theme", selection: $appearance) {
                    Text("System").tag("System")
                    Text("Light").tag("Light")
                    Text("Dark").tag("Dark")
                }.padding(17)
                divider
                VStack(alignment: .leading) {
                    Text("Message text size · \(Int(readingSize)) pt")
                    Slider(value: $readingSize, in: 15...23, step: 1).tint(ClaudeColors.accent)
                }.padding(17)
            }
        case .personalization:
            featured("Personalization", "Create saved guidance that will be included in future live API chats.", symbol: "person.text.rectangle")
            group {
                pickerStyle
                divider
                textArea("Custom instructions", text: $personalInstructions)
                divider
                textArea("Things to remember", text: $memory)
            }
            detailNote("These instructions are stored locally. They are sent as conversation context only when using your API key. They do not edit memory in your official Claude account.")
        case .api:
            featured("Live API connection", "Connect directly to Anthropic's official Messages API using your own API key.", symbol: "key.horizontal")
            group {
                HStack {
                    Label(hasKey ? "API key saved securely" : "No API key configured", systemImage: hasKey ? "checkmark.circle.fill" : "key")
                    Spacer()
                }.padding(16)
                divider
                HStack {
                    Group { if showKey { TextField("sk-ant-…", text: $apiKeyInput) } else { SecureField("sk-ant-…", text: $apiKeyInput) } }
                        .autocorrectionDisabled().textInputAutocapitalization(.never)
                    Button { showKey.toggle() } label: { Image(systemName: showKey ? "eye.slash" : "eye") }
                }.padding(16)
                divider
                HStack {
                    Button("Save key") {
                        APIKeyVault.write(apiKeyInput.trimmingCharacters(in: .whitespacesAndNewlines))
                        hasKey = APIKeyVault.read() != nil
                        apiKeyInput = ""
                    }.disabled(apiKeyInput.isEmpty)
                    Spacer()
                    if hasKey { Button("Remove key", role: .destructive) { APIKeyVault.write(""); hasKey = false } }
                }.padding(16)
            }
            detailNote("The key is saved in your iOS Keychain. Live chat calls the official Anthropic API and can incur usage charges. Claude Pro/Max subscription credentials are not interchangeable with API keys.")
        case .language:
            featured("Language", "English is currently the interface language.", symbol: "globe")
            detailNote("Claude can respond in different languages when connected to its API. Full interface translations have not been implemented.")
        case .help:
            featured("Help & support", "Find documentation or send feedback about this independent app.", symbol: "questionmark.circle")
            settingLink("Claude API documentation", url: "https://platform.claude.com/docs/en/home")
            settingLink("Official Claude help center", url: "https://support.claude.com")
            detailNote("App-specific support is separate from Anthropic.")
        case .about:
            featured("ClaudeFaithful", "Native iPhone UI study built using SwiftUI.", symbol: "info.circle")
            group {
                metric("Version", value: "0.6.0")
                divider
                metric("Backend", value: APIKeyVault.read() == nil ? "Local demo" : "Claude API")
                divider
                metric("Publisher", value: "Independent")
            }
            detailNote("Not affiliated with or endorsed by Anthropic. Includes no proprietary application binary or private authentication integration.")
        }
    }

    private var divider: some View { Rectangle().fill(ClaudeColors.stroke(scheme)).frame(height: 1).padding(.leading, 17) }

    private var pickerStyle: some View {
        Picker("Writing style", selection: $style) {
            ForEach(["Normal", "Concise", "Explanatory", "Formal"], id: \.self) { Text($0).tag($0) }
        }.padding(17)
    }

    private func detailNote(_ note: String) -> some View {
        Text(note).font(.system(size: 13.5)).lineSpacing(3)
            .foregroundStyle(ClaudeColors.muted(scheme))
            .frame(maxWidth: .infinity, alignment: .leading)
    }
    private func group<Content: View>(@ViewBuilder _ content: () -> Content) -> some View {
        VStack(spacing: 0, content: content)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 18))
    }
    private func featured(_ title: String, _ subtitle: String, symbol: String) -> some View {
        VStack(alignment: .leading, spacing: 15) {
            Image(systemName: symbol).font(.system(size: 30, weight: .ultraLight))
                .foregroundStyle(ClaudeColors.accent)
            Text(title).font(.system(size: 25, weight: .semibold, design: .serif))
            Text(subtitle).font(.system(size: 14.5)).foregroundStyle(ClaudeColors.muted(scheme))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.bottom, 9)
    }
    private func labeledField(_ title: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 12)).foregroundStyle(ClaudeColors.muted(scheme))
            TextField(title, text: text).font(.system(size: 16))
        }.padding(17)
    }
    private func textArea(_ title: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.system(size: 14, weight: .medium))
            TextEditor(text: text).frame(height: 115).scrollContentBackground(.hidden)
                .font(.system(size: 15))
        }.padding(17)
    }
    private func metric(_ label: String, value: String) -> some View {
        HStack { Text(label); Spacer(); Text(value).foregroundStyle(ClaudeColors.muted(scheme)) }
            .font(.system(size: 16)).padding(17)
    }
    private func connector(_ symbol: String, _ label: String, _ state: String) -> some View {
        HStack(spacing: 12) {
            Image(systemName: symbol).frame(width: 23)
            Text(label); Spacer()
            Text(state).font(.system(size: 12)).foregroundStyle(ClaudeColors.muted(scheme))
        }.font(.system(size: 15)).padding(17)
    }
    private func settingLink(_ label: String, url: String) -> some View {
        Link(destination: URL(string: url)!) {
            HStack {
                Text(label); Spacer(); Image(systemName: "arrow.up.right").font(.system(size: 13))
            }
            .foregroundStyle(ClaudeColors.text(scheme))
            .padding(17)
            .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 17))
        }
    }
}
