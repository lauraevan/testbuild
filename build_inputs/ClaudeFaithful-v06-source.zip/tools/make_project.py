#!/usr/bin/env python3
"""Regenerate native Xcode project file from the SwiftUI sources."""
from pathlib import Path
import json,math
from PIL import Image,ImageDraw
root=Path(__file__).resolve().parents[1]
sources=sorted((root/'Sources').glob('*.swift'))
assert len(sources) >= 8
# Home screen icon, original radial mark approximation
S=1024
im=Image.new('RGB',(S,S),(248,245,237))
d=ImageDraw.Draw(im)
CX=CY=512
for n in range(12):
 a=math.radians(n*30-90)
 distance=(99 if n%3==0 else 118)
 reach=(311 if n%2==0 else 271)
 w=38
 p1=(CX+math.cos(a)*distance+math.cos(a+math.pi/2)*w,CY+math.sin(a)*distance+math.sin(a+math.pi/2)*w)
 p2=(CX+math.cos(a)*reach,CY+math.sin(a)*reach)
 p3=(CX+math.cos(a)*distance-math.cos(a+math.pi/2)*w,CY+math.sin(a)*distance-math.sin(a+math.pi/2)*w)
 d.polygon([p1,p2,p3],fill=(203,99,72))
d.ellipse((CX-84,CY-84,CX+84,CY+84),fill=(203,99,72))
icon=root/'Assets.xcassets/AppIcon.appiconset/Icon-1024.png'
im.save(icon)
(root/'Assets.xcassets/AppIcon.appiconset/Contents.json').write_text(json.dumps({'images':[{'filename':icon.name,'idiom':'universal','platform':'ios','size':'1024x1024'}],'info':{'author':'xcode','version':1}},indent=2))
(root/'Assets.xcassets/Contents.json').write_text(json.dumps({'info':{'author':'xcode','version':1}},indent=2))
plist='''<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleDevelopmentRegion</key><string>en</string>
<key>CFBundleDisplayName</key><string>ClaudeFaithful</string>
<key>CFBundleExecutable</key><string>$(EXECUTABLE_NAME)</string>
<key>CFBundleIdentifier</key><string>$(PRODUCT_BUNDLE_IDENTIFIER)</string>
<key>CFBundleInfoDictionaryVersion</key><string>6.0</string>
<key>CFBundleName</key><string>$(PRODUCT_NAME)</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>$(MARKETING_VERSION)</string>
<key>CFBundleVersion</key><string>$(CURRENT_PROJECT_VERSION)</string>
<key>LSRequiresIPhoneOS</key><true/>
<key>UIApplicationSupportsDocumentBrowser</key><false/>
<key>UILaunchScreen</key><dict/>
<key>UISupportedInterfaceOrientations</key><array>
<string>UIInterfaceOrientationPortrait</string>
</array>
<key>NSCameraUsageDescription</key><string>Attach a photo to your chat.</string>
<key>NSMicrophoneUsageDescription</key><string>Dictate a message with your voice.</string>
<key>NSSpeechRecognitionUsageDescription</key><string>Convert your voice to text in the chat composer.</string>
<key>NSPhotoLibraryUsageDescription</key><string>Attach photos to your chat.</string>
</dict></plist>
'''
(root/'Sources/Info.plist').write_text(plist)

def i(n):return f'AC17DEAD0000000000{n:06X}'
lines=['// !$*UTF8*$!', '{','\tarchiveVersion = 1;','\tclasses = {};','\tobjectVersion = 56;','\tobjects = {']
def add(obj, content):
 lines.append(f'\t\t{i(obj)} = {{ {content} }};')
proj=1; main=2; sourcegroup=3; products=4; target=5; product=6; assets=7
sourcephase=8; resphase=9; frameworks=10; cfgproj=11; cfgtgt=12
projectdebug=13; projectrelease=14; targetdebug=15; targetrelease=16
for idx,file in enumerate(sources):
 add(100+idx,f'isa = PBXFileReference; lastKnownFileType = sourcecode.swift; path = {file.name}; sourceTree = "<group>";')
 add(200+idx,f'isa = PBXBuildFile; fileRef = {i(100+idx)};')
add(product,'isa = PBXFileReference; explicitFileType = wrapper.application; includeInIndex = 0; path = ClaudeFaithful.app; sourceTree = BUILT_PRODUCTS_DIR;')
add(assets,'isa = PBXFileReference; lastKnownFileType = folder.assetcatalog; path = Assets.xcassets; sourceTree = "<group>";')
add(300,f'isa = PBXBuildFile; fileRef = {i(assets)};')
add(main,f'isa = PBXGroup; children = ({i(sourcegroup)}, {i(assets)}, {i(products)}, ); sourceTree = "<group>";')
add(sourcegroup,f'isa = PBXGroup; children = ({", ".join(i(100+idx) for idx in range(len(sources)))}, ); path = Sources; sourceTree = "<group>";')
add(products,f'isa = PBXGroup; children = ({i(product)}, ); name = Products; sourceTree = "<group>";')
add(sourcephase,f'isa = PBXSourcesBuildPhase; buildActionMask = 2147483647; files = ({", ".join(i(200+idx) for idx in range(len(sources)))}, ); runOnlyForDeploymentPostprocessing = 0;')
add(resphase,f'isa = PBXResourcesBuildPhase; buildActionMask = 2147483647; files = ({i(300)}, ); runOnlyForDeploymentPostprocessing = 0;')
add(frameworks,'isa = PBXFrameworksBuildPhase; buildActionMask = 2147483647; files = ( ); runOnlyForDeploymentPostprocessing = 0;')
add(target,f'isa = PBXNativeTarget; buildConfigurationList = {i(cfgtgt)}; buildPhases = ({i(sourcephase)}, {i(frameworks)}, {i(resphase)}, ); buildRules = ( ); dependencies = ( ); name = ClaudeFaithful; productName = ClaudeFaithful; productReference = {i(product)}; productType = "com.apple.product-type.application";')
add(proj,f'isa = PBXProject; attributes = {{ BuildIndependentTargetsInParallel = YES; LastUpgradeCheck = 1600; TargetAttributes = {{ {i(target)} = {{ CreatedOnToolsVersion = 16.4; }}; }}; }}; buildConfigurationList = {i(cfgproj)}; compatibilityVersion = "Xcode 14.0"; developmentRegion = en; hasScannedForEncodings = 0; knownRegions = (en, Base); mainGroup = {i(main)}; productRefGroup = {i(products)}; projectDirPath = ""; projectRoot = ""; targets = ({i(target)}, );')
base={'ALWAYS_SEARCH_USER_PATHS':'NO','CLANG_ENABLE_MODULES':'YES','IPHONEOS_DEPLOYMENT_TARGET':'18.0','SDKROOT':'iphoneos','SWIFT_VERSION':'5.0','TARGETED_DEVICE_FAMILY':'"1,2"'}
targetbase={'ASSETCATALOG_COMPILER_APPICON_NAME':'AppIcon','CODE_SIGN_STYLE':'Automatic','CURRENT_PROJECT_VERSION':'1','GENERATE_INFOPLIST_FILE':'NO','INFOPLIST_FILE':'Sources/Info.plist','IPHONEOS_DEPLOYMENT_TARGET':'18.0','MARKETING_VERSION':'0.6.0','PRODUCT_BUNDLE_IDENTIFIER':'dev.bullet.claudefrontend','PRODUCT_NAME':'"$(TARGET_NAME)"','SWIFT_EMIT_LOC_STRINGS':'YES','SWIFT_VERSION':'5.0','TARGETED_DEVICE_FAMILY':'"1,2"','SUPPORTS_MACCATALYST':'NO'}
def settings(d):return ' '.join(f'{k} = {v};' for k,v in d.items())
for idx,name,setting in [(projectdebug,'Debug',dict(base,DEBUG_INFORMATION_FORMAT='dwarf',SWIFT_OPTIMIZATION_LEVEL='"-Onone"')), (projectrelease,'Release',dict(base,DEBUG_INFORMATION_FORMAT='"dwarf-with-dsym"',SWIFT_OPTIMIZATION_LEVEL='"-O"')), (targetdebug,'Debug',dict(targetbase,SWIFT_ACTIVE_COMPILATION_CONDITIONS='DEBUG')), (targetrelease,'Release',dict(targetbase))]:
 add(idx,f'isa = XCBuildConfiguration; buildSettings = {{ {settings(setting)} }}; name = {name};')
add(cfgproj,f'isa = XCConfigurationList; buildConfigurations = ({i(projectdebug)}, {i(projectrelease)}, ); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;')
add(cfgtgt,f'isa = XCConfigurationList; buildConfigurations = ({i(targetdebug)}, {i(targetrelease)}, ); defaultConfigurationIsVisible = 0; defaultConfigurationName = Release;')
lines.extend(['\t};',f'\trootObject = {i(proj)};','}'])
p=root/'ClaudeFaithful.xcodeproj/project.pbxproj';p.parent.mkdir(exist_ok=True)
p.write_text('\n'.join(lines)+'\n')
print(f'Created {p} with {len(sources)} Swift files')
