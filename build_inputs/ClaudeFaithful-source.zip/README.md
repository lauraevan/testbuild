# ClaudeFaithful v0.7 — Liquid Glass edition

**Independent, unofficial recreation; not the Claude app, and not affiliated with Anthropic.**

### Design verification
- User-supplied Claude iOS screenshot: chat header, one-row floating reply capsule, action icons, black conversation background.
- User-supplied Claude iOS screenshot: Settings account card with opaque grouped sections, close and info floating circular controls.
- Apple's SwiftUI `glassEffect(_:in:)` and `GlassEffectContainer` for actual iOS 26 rendering; older OSes use system `.ultraThinMaterial`.
- The controls and chat input now use real Liquid Glass rather than opaque rectangles masquerading as glass.

### Capabilities
Native chat history and editing, image and PDF attachments, official Claude API (personal API key required), voice dictation, local projects, artifact editor, conversation branches, chat search, local settings, and local reminders.

### Limitations
No Claude account login or subscription, no Anthropic-hosted chat sync, no actual Cowork computer control, no official account connectors. Some screens are independent local equivalents, not feature parity.

### Build
Run `bash tools/build_unsigned_ipa.sh` on macOS / Xcode 26. Output: `dist/ClaudeFaithful-unsigned.ipa`.
