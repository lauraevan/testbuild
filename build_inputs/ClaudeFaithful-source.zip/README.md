# ClaudeFaithful for iOS — v0.5.1

**Independent native iOS UI recreation. Not the official Claude app, not affiliated with Anthropic.**

ClaudeFaithful reproduces many public-facing Claude iPhone interface patterns with SwiftUI. It contains no original Claude binary, account-authentication bypass, or private APIs.

## What's new

- Restyled dark mode chat header with centered conversation title, context line, circular controls, and stop response.
- One-row chat composer based on supplied iPhone capture, with attachment thumbnails, microphone dictation, and a model/attachment/context sheet.
- Complete grouped Settings design patterned after the supplied iOS screenshot: local account card and nested pages for profile, billing links, local usage, notifications, quiet hours, privacy, shared transcripts, capabilities, Claude Code, connectors, appearance, personalization, API key, language, support, and about.
- Cowork-style **local project workspace**, Claude Code-style **local code library**, **local scheduled reminders with quiet-hour adjustment** using iOS notifications, and a connectors overview clearly showing unsupported account integrations.
- Richer Artifacts library: extract generated code blocks, save edits, preview HTML with JavaScript disabled, copy, and share via native iOS dialogs.
- Persistent local memory and custom instructions injected into live API chats. Adjustable message text size and writing style.
- Multiple local chats, history search, starred chats, deletion, incognito, PDFs/images, voice dictation, speech playback, adaptive thinking, optional API web search.

## Live functionality and honest limits

Add **your own Anthropic API key** in Settings → API connection. Chat streams responses from the official Anthropic Messages API; key material is stored in the iOS Keychain. API usage may incur charges and is different from a Claude app subscription.

**Working locally:** chat persistence, projects, code/artifact collection, editable artifacts, local reminders (requires notification permission), settings, preferences, export/share, camera/photos/files, speech, searchable conversations.

**Working only with your own API key:** actual Claude completions, Claude model selection, model thinking, web search (when enabled and permitted by API access).

**Not integrated:** Claude account login or billing, subscription benefits and usage limits, Anthropic's actual Cowork sessions, authenticated Claude Code remote sessions, official cloud scheduled tasks, computer-use remote control, Google connectors, or cross-device cloud sync. Related screens are clearly labeled and never simulate successful cloud connections.

## Build and install

An iPhone-targeted unsigned IPA requires Xcode on macOS. From this project run:

```bash
bash tools/build_unsigned_ipa.sh
```

The unsigned IPA must be signed with your own appropriate iOS signing solution before installing on a device. It is a compiled app, not a renamed source ZIP. iOS 18+.
