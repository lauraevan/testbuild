# ClaudeFaithful for iOS — v0.3

Native SwiftUI visual recreation based on publicly available Claude iOS captures. **Independent project; not Claude's original iOS binary, proprietary frontend code, or an Anthropic product.**

## New in v0.3

- Reworked dark/light palette using real device captures as visual reference
- Rebuilt radial icon and app artwork (not original app assets)
- Claude-style minimal header, upgrade strip, centered greeting, incognito entry point
- Floating chat composer with in-field model pill, voice/send controls, and growing text input
- Slide-out navigation that pushes the conversation sideways and leaves a rounded preview
- Native context sheet: camera, photo library, local files, writing style, project assignment, web search settings
- Redesigned model selection sheet with current available API model IDs and adaptive thinking
- Conversation layout with assistant serif text, user message pills, markdown/code blocks, copy/share, thumbs, response regen, and read-aloud
- Anthropic Messages API streaming (`stream: true`) for incremental replies, tool-backed web search, and optional adaptive thinking
- Projects, chats, artifacts, search, editable project instructions, local histories, and incognito mode
- Keychain-protected local API key. No embedded secrets.

## Build

Use Xcode 16+ on macOS, or the included GitHub Actions macOS runner. Build an unsigned package with:

```bash
bash tools/build_unsigned_ipa.sh
```

The unsigned IPA contains an actual compiled arm64 iOS application, but must be signed with a provisioning profile/certificate (or an applicable sideloading signer) before installation on a physical iPhone.

## Live chat

Without an API key, chat shows **clearly marked local demo responses**. Enter your own Anthropic API key under Settings to enable real responses. API calls are sent directly to the official Messages API on your device; the service may charge usage and model access varies by account. An Anthropic consumer Claude subscription is not the same as API credit. Web search may cost extra. API replies are streamed using supported text deltas; citations and richer tool artifacts are not fully reproduced.

## Limitations

The app is a visual recreation, not a reverse-engineered copy of the original executable. It doesn't implement Anthropic's account login, subscription entitlements, proprietary Cowork/Code clients, or device-to-device sync. Simulator screenshots are a development validation tool, not evidence of perfect visual fidelity. The IPA is unsigned and still requires device testing after signing.
