"""Source-level checks. The native compile requires macOS/Xcode."""
from pathlib import Path
import json
import plistlib
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]

class ProjectTests(unittest.TestCase):
    def test_swift_files_in_xcode_project(self):
        pbx = (ROOT / 'ClaudeFaithful.xcodeproj/project.pbxproj').read_text()
        for swift in (ROOT / 'Sources').glob('*.swift'):
            self.assertIn(f'path = {swift.name};', pbx)
            self.assertIn(swift.stem, pbx)

    def test_app_identity_and_permissions(self):
        with (ROOT / 'Sources/Info.plist').open('rb') as fp:
            info = plistlib.load(fp)
        self.assertEqual(info['CFBundleDisplayName'], 'ClaudeFaithful')
        self.assertIn('NSCameraUsageDescription', info)
        self.assertIn('NSMicrophoneUsageDescription', info)
        self.assertIn('NSSpeechRecognitionUsageDescription', info)
        pbx = (ROOT / 'ClaudeFaithful.xcodeproj/project.pbxproj').read_text()
        self.assertIn('dev.bullet.claudefrontend', pbx)
        self.assertNotIn('com.anthropic.claude;', pbx)

    def test_app_icon_exists(self):
        base = ROOT / 'Assets.xcassets/AppIcon.appiconset'
        data = json.loads((base/'Contents.json').read_text())
        self.assertTrue((base / data['images'][0]['filename']).is_file())

    def test_api_and_security(self):
        api = (ROOT/'Sources/ClaudeAPI.swift').read_text()
        self.assertIn('https://api.anthropic.com/v1/messages',api)
        self.assertIn('x-api-key',api)
        vault = (ROOT/'Sources/Keychain.swift').read_text()
        self.assertIn('kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly',vault)
        self.assertFalse(any(re.search(r'sk-ant-[a-zA-Z0-9]{16,}', src.read_text()) for src in (ROOT/'Sources').glob('*.swift')))

    def test_independent_build_workflow(self):
        wf = (ROOT/'.github/workflows/ios.yml').read_text()
        self.assertIn('macos-15',wf)
        self.assertIn('build_unsigned_ipa.sh',wf)
        self.assertIn('upload-artifact',wf)
        script=(ROOT/'tools/build_unsigned_ipa.sh').read_text()
        self.assertIn('CODE_SIGNING_ALLOWED=NO',script)
        self.assertIn('Payload/',script)
        self.assertIn('ClaudeFaithful-unsigned.ipa',script)

if __name__ == '__main__':
    unittest.main()
