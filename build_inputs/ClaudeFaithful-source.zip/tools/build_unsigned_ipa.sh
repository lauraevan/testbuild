#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v xcodebuild >/dev/null || { echo "Requires macOS with Xcode installed" >&2; exit 1; }
rm -rf build dist
xcodebuild -project ClaudeFaithful.xcodeproj \
  -scheme ClaudeFaithful -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath "$PWD/build" \
  CODE_SIGNING_ALLOWED=NO build
APP="$PWD/build/Build/Products/Release-iphoneos/ClaudeFaithful.app"
test -d "$APP" || { echo "Missing compiled .app" >&2; exit 1; }
mkdir -p dist/ipa/Payload
cp -R "$APP" dist/ipa/Payload/
(cd dist/ipa && /usr/bin/zip -qry ../ClaudeFaithful-unsigned.ipa Payload)
rm -rf dist/ipa
echo "Created: $PWD/dist/ClaudeFaithful-unsigned.ipa"
