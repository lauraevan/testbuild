import Foundation

enum ClaudeAPIError: LocalizedError {
    case badResponse
    case server(String)
    var errorDescription: String? {
        switch self {
        case .badResponse: return "The response couldn't be read. Please try again."
        case .server(let message): return message
        }
    }
}

struct ClaudeAPI {
    static func stream(messages: [ChatMessage], model: ClaudeModel, apiKey: String,
                       instructions: String = "", thinking: Bool = false, search: Bool = false, style: String = "Normal",
                       onDelta: @escaping @MainActor (String) -> Void) async throws {
        var request = URLRequest(url: URL(string: "https://api.anthropic.com/v1/messages")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "content-type")
        request.setValue("text/event-stream", forHTTPHeaderField: "accept")
        request.setValue(apiKey, forHTTPHeaderField: "x-api-key")
        request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        request.timeoutInterval = 140

        let apiMessages: [[String: Any]] = messages.map { message in
            var content: [[String: Any]] = []
            if !message.text.isEmpty { content.append(["type": "text", "text": message.text]) }
            for attachment in message.attachments {
                if attachment.kind == .image, let bytes = attachment.data {
                    content.append(["type": "image", "source": [
                        "type": "base64", "media_type": attachment.mimeType,
                        "data": bytes.base64EncodedString()
                    ]])
                } else if let text = attachment.extractedText {
                    content.append(["type": "text", "text": "File: \(attachment.name)\n\n\(text)"])
                }
            }
            return ["role": message.role.rawValue,
                    "content": content.isEmpty ? [["type": "text", "text": " "]] : content]
        }
        let writingGuidance: String
        switch style {
        case "Concise": writingGuidance = "Keep responses succinct and focused."
        case "Explanatory": writingGuidance = "Explain important concepts with useful examples."
        case "Formal": writingGuidance = "Use a professional and polished tone."
        default: writingGuidance = ""
        }
        var body: [String: Any] = [
            "model": model.id,
            "max_tokens": 4096,
            "messages": apiMessages,
            "stream": true
        ]
        let personal = UserDefaults.standard.string(forKey: "claudere-personal-instructions") ?? ""
        let remembered = UserDefaults.standard.string(forKey: "claudere-memory") ?? ""
        let system = [instructions, personal,
                      remembered.isEmpty ? "" : "User-provided local memory:\n" + remembered,
                      writingGuidance].filter { !$0.isEmpty }.joined(separator: "\n\n")
        if !system.isEmpty { body["system"] = system }
        if thinking { body["thinking"] = ["type": "adaptive"] }
        if search { body["tools"] = [["type": "web_search_20250305", "name": "web_search", "max_uses": 5]] }
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (bytes, response) = try await URLSession.shared.bytes(for: request)
        guard let http = response as? HTTPURLResponse else { throw ClaudeAPIError.badResponse }
        var sawContent = false
        var errorText = ""
        for try await line in bytes.lines {
            guard line.hasPrefix("data: ") else { continue }
            let payload = String(line.dropFirst(6))
            if payload == "[DONE]" { break }
            guard let data = payload.data(using: .utf8),
                  let event = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { continue }
            let eventType = event["type"] as? String ?? ""
            if eventType == "content_block_delta",
               let delta = event["delta"] as? [String: Any],
               let fragment = delta["text"] as? String {
                sawContent = true
                await onDelta(fragment)
            } else if eventType == "error",
                      let error = event["error"] as? [String: Any] {
                errorText = error["message"] as? String ?? "Streaming failed."
            } else if !(200..<300).contains(http.statusCode),
                      let error = event["error"] as? [String: Any] {
                errorText = error["message"] as? String ?? "Request failed."
            }
        }
        if !errorText.isEmpty { throw ClaudeAPIError.server(errorText) }
        if !(200..<300).contains(http.statusCode) { throw ClaudeAPIError.server("API request failed (HTTP \(http.statusCode)). Check your key and model access.") }
        if !sawContent { throw ClaudeAPIError.badResponse }
    }
}

struct DemoResponder {
    static func reply(to input: String) -> String {
        let message = input.lowercased()
        if message.contains("hello") || message.contains("hey") || message == "hi" {
            return "Hello! I can help you think through an idea, write, or work on code.\n\nThis is a **local demonstration**, not a live Claude response. To use Claude's models, add an Anthropic API key in Settings."
        }
        if message.contains("code") || message.contains("swift") || message.contains("program") {
            return "I'd be happy to help with your project.\n\nTell me what you're building, the language you're using, and any errors you've hit.\n\n*This is a local demo response. Add an Anthropic API key in Settings for AI-generated code.*"
        }
        if message.contains("write") || message.contains("email") {
            return "A strong draft usually starts with three things:\n\n1. **Audience:** Who will read it?\n2. **Purpose:** What should they understand or do?\n3. **Tone:** Casual, warm, direct, or formal?\n\n*Local demo mode is enabled. Connect an API key for a tailored draft.*"
        }
        return "I can help you explore that. What outcome are you looking for, and what context should I keep in mind?\n\n*This is a built-in sample response, not Anthropic's AI. Add your own API key in Settings for live responses.*"
    }
}
