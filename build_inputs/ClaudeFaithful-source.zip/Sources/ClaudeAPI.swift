import Foundation

enum ClaudeAPIError: LocalizedError {
    case badResponse
    case server(String)
    var errorDescription: String? {
        switch self {
        case .badResponse: return "Claude returned an unreadable response."
        case .server(let message): return message
        }
    }
}

struct ClaudeAPI {
    static func reply(messages: [ChatMessage], model: ClaudeModel, apiKey: String, instructions: String = "") async throws -> String {
        var request = URLRequest(url: URL(string: "https://api.anthropic.com/v1/messages")!)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "content-type")
        request.setValue(apiKey, forHTTPHeaderField: "x-api-key")
        request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        request.timeoutInterval = 90

        let apiMessages: [[String: Any]] = messages.map { message in
            var content: [[String: Any]] = []
            if !message.text.isEmpty {
                content.append(["type": "text", "text": message.text])
            }
            for attachment in message.attachments {
                if attachment.kind == .image, let bytes = attachment.data {
                    content.append(["type": "image", "source": [
                        "type": "base64", "media_type": attachment.mimeType,
                        "data": bytes.base64EncodedString()
                    ]])
                } else if let text = attachment.extractedText {
                    content.append(["type": "text", "text": "File: \(attachment.name)\n\n\(text)"])
                }
            }
            return ["role": message.role.rawValue, "content": content.isEmpty ? [["type": "text", "text": " "]] : content]
        }
        var body: [String: Any] = [
            "model": model.id,
            "max_tokens": 2048,
            "messages": apiMessages
        ]
        if !instructions.isEmpty { body["system"] = instructions }
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw ClaudeAPIError.badResponse }
        if !(200..<300).contains(http.statusCode) {
            if let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let error = object["error"] as? [String: Any],
               let description = error["message"] as? String {
                throw ClaudeAPIError.server(description)
            }
            throw ClaudeAPIError.server("API error \(http.statusCode). Verify your key and selected model.")
        }
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let blocks = object["content"] as? [[String: Any]] else {
            throw ClaudeAPIError.badResponse
        }
        let text = blocks.compactMap { $0["text"] as? String }.joined(separator: "\n\n")
        return text.isEmpty ? "No text was returned." : text
    }
}

struct DemoResponder {
    static func reply(to input: String) -> String {
        let message = input.lowercased()
        if message.contains("hello") || message.contains("hi ") || message == "hi" {
            return "Hey! I'm ready to help. This is the local recreation demo. Add an Anthropic API key in Settings to connect to the real Claude models."
        }
        if message.contains("code") || message.contains("swift") || message.contains("program") {
            return "Absolutely. Tell me what you're building, what language you're using, and where you're stuck.\n\nFor real code generation, connect your own Claude API key in Settings. This response comes from the offline demo."
        }
        if message.contains("write") || message.contains("email") {
            return "I can help turn a rough idea into something clear and polished. Share the audience, purpose, and tone you want.\n\n*Demo mode is on. Connect an API key for generated responses.*"
        }
        return "That's an interesting direction. What outcome are you aiming for, and what constraints should I work around?\n\n*This is a built-in demonstration response, not an answer from Anthropic. Add an API key in Settings for live replies.*"
    }
}
