import SwiftUI

// Real iOS 26 Liquid Glass. Older systems retain a subtle translucent material
// rather than presenting a fake iOS 26 effect.
struct GlassCircleModifier: ViewModifier {
    @Environment(\.colorScheme) private var scheme
    func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.interactive(), in: Circle())
        } else {
            content.background(.ultraThinMaterial, in: Circle())
                .overlay(Circle().strokeBorder(.white.opacity(scheme == .dark ? 0.13 : 0.20), lineWidth: 0.8))
        }
    }
}

struct GlassComposerModifier: ViewModifier {
    @Environment(\.colorScheme) private var scheme
    var radius: CGFloat = 30
    func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
        } else {
            content.background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: radius, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous)
                    .strokeBorder(.white.opacity(scheme == .dark ? 0.15 : 0.24), lineWidth: 0.8))
        }
    }
}

struct GlassAccentCircleModifier: ViewModifier {
    var tint: Color
    func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.glassEffect(.regular.tint(tint).interactive(), in: Circle())
        } else {
            content.background(tint, in: Circle())
        }
    }
}

extension View {
    func claudeGlassCircle() -> some View { modifier(GlassCircleModifier()) }
    func claudeGlassComposer(radius: CGFloat = 30) -> some View { modifier(GlassComposerModifier(radius: radius)) }
    func claudeAccentGlass(_ color: Color) -> some View { modifier(GlassAccentCircleModifier(tint: color)) }
}

// Non-glass surface for content cards, per Apple's Liquid Glass hierarchy guidance.
struct ClaudeContentCard<Content: View>: View {
    @Environment(\.colorScheme) private var scheme
    let radius: CGFloat
    @ViewBuilder var content: Content
    var body: some View {
        content.background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: radius, style: .continuous))
    }
}

struct ClaudeGlassGroup<Content: View>: View {
    let spacing: CGFloat
    let content: () -> Content
    init(spacing: CGFloat = 15, @ViewBuilder content: @escaping () -> Content) {
        self.spacing = spacing
        self.content = content
    }
    var body: some View {
        if #available(iOS 26.0, *) {
            GlassEffectContainer(spacing: spacing) { content() }
        } else {
            content()
        }
    }
}
