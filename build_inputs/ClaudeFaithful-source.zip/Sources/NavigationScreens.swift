import SwiftUI

struct SidebarView: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @State private var search = ""

    private var recent: [Conversation] {
        store.sortedConversations.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) || $0.messages.contains(where: { $0.text.localizedCaseInsensitiveContains(search) }) }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                ClaudeMark(size: 26)
                Text("Claude").font(.system(size: 24, design: .serif))
                Spacer()
                RoundIconButton(symbol: "sidebar.left", background: false) { store.sidebarVisible = false }
            }
            .padding(.horizontal, 19)
            .padding(.top, 13)
            .padding(.bottom, 18)

            Button { store.newChat() } label: {
                HStack(spacing: 12) {
                    Image(systemName: "square.and.pencil").font(.system(size: 17))
                    Text("New chat").font(.system(size: 15, weight: .semibold))
                    Spacer()
                }
                .padding(.horizontal, 15)
                .frame(height: 45)
                .foregroundStyle(ClaudeColors.text(scheme))
                .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 13))
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 15)

            HStack(spacing: 9) {
                Image(systemName: "magnifyingglass").font(.system(size: 14))
                TextField("Search chats", text: $search).font(.system(size: 14))
                    .autocorrectionDisabled()
            }
            .foregroundStyle(ClaudeColors.muted(scheme))
            .padding(.horizontal, 15)
            .frame(height: 40)
            .background(ClaudeColors.bubble(scheme), in: RoundedRectangle(cornerRadius: 11))
            .padding(.horizontal, 15)
            .padding(.top, 10)

            ScrollView {
                VStack(alignment: .leading, spacing: 2) {
                    sideNav(symbol: "bubble.left.and.bubble.right", title: "Chats") { store.navigate(.chats) }
                    sideNav(symbol: "folder", title: "Projects") { store.navigate(.projects) }
                    sideNav(symbol: "square.stack", title: "Artifacts") { store.navigate(.artifacts) }

                    if recent.contains(where: { $0.starred }) {
                        sectionLabel("Starred")
                        ForEach(recent.filter { $0.starred }) { conversation in
                            conversationRow(conversation)
                        }
                    }
                    sectionLabel("Recents")
                    if recent.isEmpty {
                        Text("Your conversations will appear here")
                            .font(.system(size: 12))
                            .foregroundStyle(ClaudeColors.muted(scheme))
                            .padding(.horizontal, 18)
                            .padding(.top, 12)
                    } else {
                        ForEach(recent.filter { !$0.starred }.prefix(30)) { conversation in
                            conversationRow(conversation)
                        }
                    }
                }
                .padding(.horizontal, 9)
                .padding(.top, 20)
            }
            Divider().opacity(0.45)
            Button { store.navigate(.settings) } label: {
                HStack(spacing: 12) {
                    Text("B")
                        .font(.system(size: 15, weight: .semibold))
                        .frame(width: 35, height: 35)
                        .foregroundStyle(ClaudeColors.text(scheme))
                        .background(ClaudeColors.bubble(scheme), in: Circle())
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Local account").font(.system(size: 14, weight: .medium))
                        Text(store.isDemoMode ? "Demo mode" : "API connected")
                            .font(.system(size: 12)).foregroundStyle(ClaudeColors.muted(scheme))
                    }
                    Spacer()
                    Image(systemName: "ellipsis").font(.system(size: 17))
                }
                .foregroundStyle(ClaudeColors.text(scheme))
                .padding(.horizontal, 18)
                .padding(.vertical, 12)
            }
            .buttonStyle(.plain)
        }
        .foregroundStyle(ClaudeColors.text(scheme))
    }

    private func sideNav(symbol: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 15) {
                Image(systemName: symbol).font(.system(size: 16)).frame(width: 21)
                Text(title).font(.system(size: 15))
                Spacer()
            }
            .foregroundStyle(ClaudeColors.text(scheme))
            .padding(.horizontal, 16)
            .frame(height: 42)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }
    private func sectionLabel(_ text: String) -> some View {
        Text(text).font(.system(size: 12, weight: .medium))
            .foregroundStyle(ClaudeColors.muted(scheme))
            .padding(.leading, 17).padding(.top, 23).padding(.bottom, 8)
    }
    private func conversationRow(_ conversation: Conversation) -> some View {
        Button { store.openChat(conversation.id) } label: {
            HStack(spacing: 10) {
                Image(systemName: "bubble.left").font(.system(size: 13))
                Text(conversation.title)
                    .font(.system(size: 14))
                    .lineLimit(1)
                Spacer(minLength: 0)
            }
            .foregroundStyle(ClaudeColors.text(scheme))
            .padding(.horizontal, 16)
            .frame(height: 39)
            .background(store.currentID == conversation.id && store.destination == .chat ? ClaudeColors.bubble(scheme) : .clear, in: RoundedRectangle(cornerRadius: 10))
        }
        .buttonStyle(.plain)
    }
}

struct ScreenBar: View {
    @EnvironmentObject private var store: ChatStore
    var title: String
    var rightSymbol: String? = nil
    var rightAction: (() -> Void)? = nil

    var body: some View {
        HStack {
            RoundIconButton(symbol: "line.3.horizontal.decrease") { store.sidebarVisible = true }
            Spacer()
            Text(title).font(.system(size: 17, weight: .semibold))
            Spacer()
            if let rightSymbol, let rightAction {
                RoundIconButton(symbol: rightSymbol, action: rightAction)
            } else {
                Color.clear.frame(width: 42, height: 42)
            }
        }
        .padding(.horizontal, 12)
        .frame(height: 55)
    }
}

struct ChatsListScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @State private var search = ""

    private var filtered: [Conversation] {
        store.sortedConversations.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) }
    }

    var body: some View {
        VStack(spacing: 0) {
            ScreenBar(title: "Chats", rightSymbol: "square.and.pencil") { store.newChat() }
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass")
                TextField("Search conversations", text: $search)
                    .autocorrectionDisabled()
            }
            .font(.system(size: 14))
            .foregroundStyle(ClaudeColors.muted(scheme))
            .padding(13)
            .background(ClaudeColors.bubble(scheme), in: RoundedRectangle(cornerRadius: 11))
            .padding(.horizontal, 18)
            .padding(.bottom, 10)
            if filtered.isEmpty {
                ContentUnavailableView("No conversations yet", systemImage: "bubble.left.and.bubble.right", description: Text("Start a new chat to see it here."))
                Spacer()
            } else {
                List {
                    ForEach(filtered) { conversation in
                        Button { store.openChat(conversation.id) } label: {
                            HStack {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text(conversation.title)
                                        .font(.system(size: 15, weight: .medium))
                                        .foregroundStyle(ClaudeColors.text(scheme))
                                        .lineLimit(1)
                                    Text(conversation.updatedAt, style: .relative)
                                        .font(.system(size: 12))
                                        .foregroundStyle(ClaudeColors.muted(scheme))
                                }
                                Spacer()
                                if conversation.starred { Image(systemName: "star.fill").font(.system(size: 11)).foregroundStyle(ClaudeColors.accent) }
                                Image(systemName: "chevron.right").font(.system(size: 11)).foregroundStyle(ClaudeColors.muted(scheme))
                            }
                            .padding(.vertical, 7)
                        }
                        .listRowBackground(ClaudeColors.background(scheme))
                        .swipeActions(edge: .trailing) {
                            Button(role: .destructive) { store.delete(conversation.id) } label: { Label("Delete", systemImage: "trash") }
                            Button { store.toggleStar(conversation.id) } label: { Label("Star", systemImage: "star") }.tint(.orange)
                        }
                    }
                }
                .scrollContentBackground(.hidden)
                .listStyle(.plain)
            }
        }
    }
}

struct ProjectsScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @State private var createProject = false
    @State private var name = ""
    @State private var description = ""

    var body: some View {
        VStack(spacing: 0) {
            ScreenBar(title: "Projects", rightSymbol: "plus") { createProject = true }
            if store.projects.isEmpty {
                Spacer()
                VStack(spacing: 15) {
                    Image(systemName: "folder.badge.plus").font(.system(size: 33, weight: .ultraLight))
                    Text("A place for your work").font(.system(size: 24, design: .serif))
                    Text("Keep related conversations and project instructions together.")
                        .font(.system(size: 14))
                        .multilineTextAlignment(.center)
                        .foregroundStyle(ClaudeColors.muted(scheme))
                    Button("Create project") { createProject = true }
                        .buttonStyle(.borderedProminent)
                        .tint(ClaudeColors.accent)
                        .padding(.top, 7)
                }
                .padding(.horizontal, 35)
                Spacer()
            } else {
                List(store.projects) { project in
                    Button { store.navigate(.project(project.id)) } label: {
                        HStack(spacing: 14) {
                            Image(systemName: "folder").font(.system(size: 20)).frame(width: 27)
                            VStack(alignment: .leading, spacing: 5) {
                                Text(project.name).font(.system(size: 16, weight: .medium))
                                Text(project.details.isEmpty ? "Project" : project.details)
                                    .font(.system(size: 12))
                                    .foregroundStyle(ClaudeColors.muted(scheme)).lineLimit(1)
                            }
                            Spacer()
                            Image(systemName: "chevron.right").font(.system(size: 12))
                        }
                        .foregroundStyle(ClaudeColors.text(scheme))
                        .padding(.vertical, 10)
                    }
                    .listRowBackground(ClaudeColors.background(scheme))
                }
                .scrollContentBackground(.hidden).listStyle(.plain)
            }
        }
        .sheet(isPresented: $createProject) {
            NavigationStack {
                Form {
                    TextField("Project name", text: $name)
                    TextField("What is this project about?", text: $description, axis: .vertical)
                        .lineLimit(3...5)
                }
                .navigationTitle("New project")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) { Button("Cancel") { createProject = false } }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Create") {
                            store.addProject(name: name, details: description)
                            name = ""; description = ""; createProject = false
                        }.disabled(name.trimmingCharacters(in: .whitespaces).isEmpty)
                    }
                }
            }
            .tint(ClaudeColors.accent)
        }
    }
}

struct ProjectDetailScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    let projectID: UUID
    @State private var editOpen = false
    @State private var draftInstructions = ""
    @State private var draftDetails = ""
    @State private var deleting = false

    private var project: ClaudeProject? { store.projects.first { $0.id == projectID } }
    private var conversations: [Conversation] { store.sortedConversations.filter { $0.projectID == projectID } }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                RoundIconButton(symbol: "chevron.left") { store.navigate(.projects) }
                Spacer()
                Text(project?.name ?? "Project").font(.system(size: 17, weight: .medium))
                Spacer()
                Menu {
                    Button("Edit project", systemImage: "pencil") {
                        draftDetails = project?.details ?? ""
                        draftInstructions = project?.instructions ?? ""
                        editOpen = true
                    }
                    Button("Delete project", systemImage: "trash", role: .destructive) { deleting = true }
                } label: { Image(systemName: "ellipsis").frame(width: 42, height: 42) }
            }
            .padding(.horizontal, 12)
            if let project {
                ScrollView {
                    VStack(alignment: .leading, spacing: 22) {
                        Image(systemName: "folder").font(.system(size: 33)).foregroundStyle(ClaudeColors.accent)
                        Text(project.name).font(.system(size: 29, design: .serif))
                        if !project.details.isEmpty { Text(project.details).font(.system(size: 14)).foregroundStyle(ClaudeColors.muted(scheme)) }
                        Button { store.newChat(); store.addToProjectForNextChat(projectID) } label: {
                            Label("New chat in project", systemImage: "square.and.pencil")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent).tint(ClaudeColors.accent)
                        Text("Project instructions").font(.system(size: 16, weight: .semibold))
                        Text(project.instructions.isEmpty ? "No custom instructions yet. Tap the menu to add some." : project.instructions)
                            .font(.system(size: 14)).foregroundStyle(ClaudeColors.muted(scheme))
                        Divider()
                        Text("Chats").font(.system(size: 16, weight: .semibold))
                        if conversations.isEmpty { Text("No conversations yet").foregroundStyle(ClaudeColors.muted(scheme)) }
                        ForEach(conversations) { conversation in
                            Button { store.openChat(conversation.id) } label: {
                                HStack {
                                    Image(systemName: "bubble.left")
                                    Text(conversation.title).lineLimit(1)
                                    Spacer()
                                    Image(systemName: "chevron.right").font(.system(size: 11))
                                }
                                .padding(.vertical, 9)
                            }
                            .foregroundStyle(ClaudeColors.text(scheme))
                        }
                    }
                    .padding(22)
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
        }
        .sheet(isPresented: $editOpen) {
            NavigationStack {
                Form {
                    Section("Description") { TextField("Description", text: $draftDetails, axis: .vertical).lineLimit(2...5) }
                    Section("Instructions") { TextEditor(text: $draftInstructions).frame(minHeight: 190) }
                }
                .navigationTitle("Edit project")
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) { Button("Cancel") { editOpen = false } }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Save") {
                            if var value = project {
                                value.details = draftDetails
                                value.instructions = draftInstructions
                                store.updateProject(value)
                            }
                            editOpen = false
                        }
                    }
                }
            }
        }
        .confirmationDialog("Delete project? Chats will be kept.", isPresented: $deleting) {
            Button("Delete project", role: .destructive) { store.deleteProject(projectID) }
        }
    }
}

struct ArtifactsScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @State private var selected: ArtifactEntry?

    private var artifacts: [ArtifactEntry] {
        store.sortedConversations.flatMap { conversation in
            conversation.messages.filter { $0.role == .assistant }.flatMap { message in
                let parts = message.text.components(separatedBy: "```")
                return parts.indices.filter { $0.isMultiple(of: 2) == false }.map { index in
                    ArtifactEntry(id: "\(message.id.uuidString)-\(index)", title: conversation.title, body: parts[index])
                }
            }
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            ScreenBar(title: "Artifacts")
            if artifacts.isEmpty {
                Spacer()
                VStack(spacing: 15) {
                    Image(systemName: "square.stack.3d.up").font(.system(size: 36, weight: .ultraLight))
                    Text("Your artifacts").font(.system(size: 25, design: .serif))
                    Text("Code blocks from Claude's replies will appear here.")
                        .font(.system(size: 14))
                        .foregroundStyle(ClaudeColors.muted(scheme))
                        .multilineTextAlignment(.center)
                }
                .padding(.horizontal, 30)
                Spacer()
            } else {
                List(artifacts) { artifact in
                    Button { selected = artifact } label: {
                        HStack {
                            Image(systemName: "chevron.left.forwardslash.chevron.right")
                            VStack(alignment: .leading, spacing: 4) {
                                Text(artifact.title).font(.system(size: 14, weight: .semibold))
                                Text(artifact.body).font(.system(size: 12)).lineLimit(2)
                            }
                        }
                        .foregroundStyle(ClaudeColors.text(scheme))
                    }
                    .listRowBackground(ClaudeColors.background(scheme))
                }
                .scrollContentBackground(.hidden)
            }
        }
        .sheet(item: $selected) { artifact in
            NavigationStack {
                ScrollView {
                    Text(artifact.body)
                        .font(.system(size: 13, design: .monospaced))
                        .textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                }
                .navigationTitle("Artifact")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) { ShareLink(item: artifact.body) { Image(systemName: "square.and.arrow.up") } }
                    ToolbarItem(placement: .topBarLeading) { Button("Done") { selected = nil } }
                }
            }
        }
    }
}

struct ArtifactEntry: Identifiable {
    var id: String
    var title: String
    var body: String
}
