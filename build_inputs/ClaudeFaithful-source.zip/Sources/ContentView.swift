import SwiftUI

@main
struct ClaudeFaithfulApp: App {
    @StateObject private var store = ChatStore()
    @AppStorage("claudere-appearance") private var appearance = "System"

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .preferredColorScheme(appearance == "Dark" ? .dark : appearance == "Light" ? .light : nil)
        }
    }
}

struct ContentView: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @State private var modelSheet = false

    var body: some View {
        ZStack(alignment: .leading) {
            Group {
                switch store.destination {
                case .chat:
                    ChatScreen(openModels: { modelSheet = true })
                case .chats:
                    ChatsListScreen()
                case .projects:
                    ProjectsScreen()
                case .project(let id):
                    ProjectDetailScreen(projectID: id)
                case .artifacts:
                    ArtifactsScreen()
                case .settings:
                    SettingsScreen()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(ClaudeColors.background(scheme))
            .disabled(store.sidebarVisible)

            if store.sidebarVisible {
                Color.black.opacity(scheme == .dark ? 0.52 : 0.23)
                    .ignoresSafeArea()
                    .onTapGesture { withAnimation(.snappy(duration: 0.26)) { store.sidebarVisible = false } }
                    .transition(.opacity)
                    .zIndex(1)
                SidebarView()
                    .frame(width: min(UIScreen.main.bounds.width * 0.84, 356))
                    .frame(maxHeight: .infinity)
                    .background(ClaudeColors.sidebar(scheme))
                    .transition(.move(edge: .leading))
                    .zIndex(2)
            }
        }
        .animation(.snappy(duration: 0.27), value: store.sidebarVisible)
        .sheet(isPresented: $modelSheet) { ModelSheet() }
        .tint(ClaudeColors.accent)
    }
}

struct AppHeader: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    var openModels: () -> Void
    @State private var menuOpen = false
    @State private var renameText = ""
    @State private var renameOpen = false
    @State private var projectPicker = false
    @State private var deleteConfirmation = false

    var body: some View {
        HStack {
            RoundIconButton(symbol: store.activeConversation == nil ? "line.3.horizontal.decrease" : "chevron.left", background: store.activeConversation == nil) {
                if store.activeConversation != nil {
                    store.navigate(.chats)
                } else {
                    store.sidebarVisible = true
                }
            }
            Spacer()
            Button(action: openModels) {
                HStack(spacing: 5) {
                    Text(store.selectedModel.name)
                        .font(.system(size: 16, weight: .medium, design: .serif))
                    Image(systemName: "chevron.down").font(.system(size: 10, weight: .medium))
                }
                .foregroundStyle(ClaudeColors.text(scheme))
            }
            .buttonStyle(.plain)
            Spacer()
            Menu {
                Button { store.newChat() } label: { Label("New chat", systemImage: "square.and.pencil") }
                Button { store.newChat(incognito: true) } label: { Label("Incognito chat", systemImage: "eye.slash") }
                if let conversation = store.activeConversation {
                    Button {
                        renameText = conversation.title
                        renameOpen = true
                    } label: { Label("Rename", systemImage: "pencil") }
                    Button { store.toggleStar(conversation.id) } label: {
                        Label(conversation.starred ? "Unstar" : "Star", systemImage: conversation.starred ? "star.slash" : "star")
                    }
                    Button { projectPicker = true } label: { Label("Add to project", systemImage: "folder") }
                    ShareLink(item: conversation.messages.map { "\($0.role == .user ? "You" : "Claude"): \($0.text)" }.joined(separator: "\n\n")) {
                        Label("Share conversation", systemImage: "square.and.arrow.up")
                    }
                    Divider()
                    Button(role: .destructive) { deleteConfirmation = true } label: { Label("Delete", systemImage: "trash") }
                }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 19, weight: .medium))
                    .foregroundStyle(ClaudeColors.text(scheme))
                    .frame(width: 42, height: 42)
            }
            .accessibilityLabel("Conversation options")
        }
        .padding(.horizontal, 12)
        .frame(height: 55)
        .alert("Rename chat", isPresented: $renameOpen) {
            TextField("Title", text: $renameText)
            Button("Save") { if let id = store.currentID { store.rename(id, to: renameText) } }
            Button("Cancel", role: .cancel) {}
        }
        .confirmationDialog("Delete this conversation?", isPresented: $deleteConfirmation) {
            Button("Delete conversation", role: .destructive) { if let id = store.currentID { store.delete(id) } }
        }
        .sheet(isPresented: $projectPicker) {
            NavigationStack {
                List {
                    Button("No project") { if let id = store.currentID { store.addToProject(id, projectID: nil) }; projectPicker = false }
                    ForEach(store.projects) { project in
                        Button(project.name) {
                            if let id = store.currentID { store.addToProject(id, projectID: project.id) }
                            projectPicker = false
                        }
                    }
                }
                .navigationTitle("Add to project")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { projectPicker = false } } }
            }
            .presentationDetents([.medium, .large])
        }
    }
}

struct ChatScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    var openModels: () -> Void
    @State private var draft = ""
    @State private var pendingAttachments: [ChatAttachment] = []

    var body: some View {
        VStack(spacing: 0) {
            AppHeader(openModels: openModels)
            if let conversation = store.activeConversation {
                conversationContent(conversation)
            } else {
                emptyConversation
            }
            if let error = store.lastError {
                HStack(alignment: .firstTextBaseline) {
                    Image(systemName: "exclamationmark.circle")
                    Text(error).font(.system(size: 12))
                    Spacer()
                    Button { store.lastError = nil } label: { Image(systemName: "xmark") }
                }
                .foregroundStyle(.red)
                .padding(.horizontal, 20)
                .padding(.vertical, 7)
            }
            ChatComposer(text: $draft, attachments: $pendingAttachments, disabled: store.isSending) {
                let attachments = pendingAttachments
                pendingAttachments = []
                let text = draft
                draft = ""
                store.send(text, attachments: attachments)
            }
        }
        .background(ClaudeColors.background(scheme))
    }

    private var emptyConversation: some View {
        VStack(spacing: 0) {
            HStack {
                if store.incognito {
                    Label("Incognito chat", systemImage: "eye.slash")
                        .font(.system(size: 12)).foregroundStyle(ClaudeColors.muted(scheme))
                } else {
                    Text("Get more with Claude Pro")
                        .foregroundStyle(ClaudeColors.text(scheme))
                        .font(.system(size: 13))
                    Spacer()
                    Button("Upgrade") { store.navigate(.settings) }
                        .font(.system(size: 13))
                        .foregroundStyle(Color(red: 0.32, green: 0.48, blue: 0.65))
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 10)
            Rectangle().fill(ClaudeColors.stroke(scheme)).frame(height: 0.5)
            Spacer(minLength: 18)
            VStack(spacing: 18) {
                ClaudeMark(size: 47)
                Text(greeting)
                    .font(.system(size: 31, weight: .regular, design: .serif))
                    .multilineTextAlignment(.center)
                    .minimumScaleFactor(0.75)
                    .lineLimit(3)
                    .foregroundStyle(ClaudeColors.text(scheme))
                    .padding(.horizontal, 22)
            }
            .offset(y: -15)
            Spacer(minLength: 14)
        }
    }

    private var greeting: String {
        let hour = Calendar.current.component(.hour, from: .now)
        if hour < 12 { return "How can I help you\nthis morning?" }
        if hour < 17 { return "How can I help you\nthis afternoon?" }
        return "How can I help you\nthis evening?"
    }

    private func conversationContent(_ conversation: Conversation) -> some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 25) {
                    if conversation.incognito {
                        Label("Incognito chat · Not saved on this device", systemImage: "eye.slash")
                            .font(.caption)
                            .foregroundStyle(ClaudeColors.muted(scheme))
                            .frame(maxWidth: .infinity)
                    }
                    ForEach(conversation.messages) { message in
                        ChatMessageView(message: message)
                            .id(message.id)
                    }
                    if store.isSending {
                        HStack(spacing: 10) {
                            ClaudeMark(size: 21)
                            ProgressView().controlSize(.small)
                            Text("Thinking...")
                                .font(.system(size: 13))
                                .foregroundStyle(ClaudeColors.muted(scheme))
                        }
                        .id("thinking")
                    }
                    Text("Claude can make mistakes. Please double-check responses.")
                        .font(.system(size: 11))
                        .foregroundStyle(ClaudeColors.muted(scheme))
                        .frame(maxWidth: .infinity)
                        .padding(.top, 4)
                }
                .padding(.horizontal, 18)
                .padding(.top, 23)
                .padding(.bottom, 20)
            }
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: conversation.messages.count) { _, _ in
                if let id = conversation.messages.last?.id {
                    withAnimation(.easeOut(duration: 0.25)) { proxy.scrollTo(id, anchor: .bottom) }
                }
            }
            .onChange(of: store.isSending) { _, newValue in
                if newValue { withAnimation { proxy.scrollTo("thinking", anchor: .bottom) } }
                else if let id = conversation.messages.last?.id { withAnimation { proxy.scrollTo(id, anchor: .bottom) } }
            }
        }
    }
}

struct ChatMessageView: View {
    @Environment(\.colorScheme) private var scheme
    let message: ChatMessage

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            if message.role == .user { Spacer(minLength: 40) }
            VStack(alignment: .leading, spacing: 10) {
                ForEach(message.attachments) { attachment in
                    if attachment.kind == .image,
                       let data = attachment.data,
                       let image = UIImage(data: data) {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: 250, maxHeight: 240)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    } else {
                        Label(attachment.name, systemImage: "doc.text")
                            .font(.system(size: 13))
                            .padding(10)
                            .background(ClaudeColors.bubble(scheme), in: RoundedRectangle(cornerRadius: 11))
                    }
                }
                if !message.text.isEmpty {
                    if message.role == .assistant {
                        RichMessageText(text: message.text)
                    } else {
                        Text(message.text)
                            .font(.system(size: 15.5))
                            .lineSpacing(5)
                            .foregroundStyle(ClaudeColors.text(scheme))
                            .textSelection(.enabled)
                    }
                }
                if message.role == .assistant {
                    HStack(spacing: 19) {
                        Button { UIPasteboard.general.string = message.text } label: {
                            Image(systemName: "document.on.document")
                        }
                        ShareLink(item: message.text) { Image(systemName: "square.and.arrow.up") }
                    }
                    .font(.system(size: 13))
                    .foregroundStyle(ClaudeColors.muted(scheme))
                    .padding(.top, 3)
                }
            }
            .padding(message.role == .user ? 14 : 0)
            .background(message.role == .user ? ClaudeColors.bubble(scheme) : .clear,
                        in: RoundedRectangle(cornerRadius: 18))
            if message.role == .assistant { Spacer(minLength: 12) }
        }
    }
}

struct ModelSheet: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {
            SheetHandle()
            HStack {
                RoundIconButton(symbol: "xmark") { dismiss() }
                Spacer()
                Text("Select model").font(.system(size: 16, weight: .semibold))
                Spacer()
                Color.clear.frame(width: 42, height: 42)
            }
            .padding(.horizontal, 10)
            .padding(.bottom, 5)
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    ForEach(ClaudeModel.all) { model in
                        Button {
                            store.chooseModel(model)
                            dismiss()
                        } label: {
                            HStack(spacing: 10) {
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(model.name).font(.system(size: 17))
                                        .foregroundStyle(ClaudeColors.text(scheme))
                                    Text(model.subtitle).font(.system(size: 13))
                                        .foregroundStyle(ClaudeColors.muted(scheme))
                                }
                                Spacer()
                                if model == store.selectedModel {
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 17))
                                        .foregroundStyle(.blue)
                                }
                            }
                            .padding(.vertical, 14)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                    Divider().padding(.vertical, 8)
                    Toggle(isOn: $store.thinkEnabled) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Extended thinking").font(.system(size: 16))
                            Text("Think longer for complex tasks")
                                .font(.system(size: 12)).foregroundStyle(ClaudeColors.muted(scheme))
                        }
                    }
                    .tint(ClaudeColors.accent)
                    .padding(.vertical, 11)
                    Text("Model access and capabilities depend on your own API account.")
                        .font(.system(size: 12))
                        .foregroundStyle(ClaudeColors.muted(scheme))
                        .padding(.top, 14)
                }
                .padding(.horizontal, 26)
            }
        }
        .background(ClaudeColors.background(scheme))
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.hidden)
    }
}


struct RichMessageText: View {
    @Environment(\.colorScheme) private var scheme
    let text: String
    private var parts: [String] { text.components(separatedBy: "```") }

    var body: some View {
        VStack(alignment: .leading, spacing: 11) {
            ForEach(Array(parts.enumerated()), id: \.offset) { index, part in
                if index.isMultiple(of: 2) {
                    if !part.isEmpty {
                        Text((try? AttributedString(markdown: part)) ?? AttributedString(part))
                            .font(.system(size: 15.5))
                            .lineSpacing(5)
                            .foregroundStyle(ClaudeColors.text(scheme))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                } else {
                    let lines = part.split(separator: "\n", maxSplits: 1, omittingEmptySubsequences: false)
                    let language = lines.first.map(String.init) ?? "code"
                    let code = lines.count > 1 ? String(lines[1]) : part
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            Text(language.isEmpty ? "Code" : language)
                                .font(.system(size: 11, weight: .medium))
                            Spacer()
                            Button {
                                UIPasteboard.general.string = code
                            } label: {
                                Label("Copy", systemImage: "document.on.document")
                                    .font(.system(size: 11))
                            }
                            .buttonStyle(.plain)
                        }
                        .foregroundStyle(ClaudeColors.muted(scheme))
                        .padding(10)
                        Divider()
                        ScrollView(.horizontal) {
                            Text(code)
                                .font(.system(size: 12.5, design: .monospaced))
                                .textSelection(.enabled)
                                .padding(12)
                        }
                    }
                    .background(ClaudeColors.bubble(scheme), in: RoundedRectangle(cornerRadius: 11))
                }
            }
        }
    }
}
