import SwiftUI
import UIKit

@main
struct ClaudeFaithfulApp: App {
    @StateObject private var store = ChatStore()
    // Dark by default to match Claude's currently photographed iPhone layout.
    @AppStorage("claudere-appearance") private var appearance = "Dark"

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .preferredColorScheme(appearance == "Dark" ? .dark : appearance == "Light" ? .light : nil)
        }
    }
}

struct ContentView: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @State private var modelSheet = false

    private var drawerWidth: CGFloat { min(UIScreen.main.bounds.width * 0.77, 346) }

    var body: some View {
        ZStack(alignment: .leading) {
            destination
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(ClaudeColors.background(scheme))
                .offset(x: store.sidebarVisible ? drawerWidth : 0)
                .scaleEffect(store.sidebarVisible ? 0.97 : 1, anchor: .leading)
                .clipShape(RoundedRectangle(cornerRadius: store.sidebarVisible ? 28 : 0))
                .overlay {
                    if store.sidebarVisible {
                        Color.black.opacity(0.18)
                            .clipShape(RoundedRectangle(cornerRadius: 28))
                            .onTapGesture { closeDrawer() }
                    }
                }
                .zIndex(1)

            if store.sidebarVisible {
                SidebarView()
                    .frame(width: drawerWidth)
                    .frame(maxHeight: .infinity)
                    .background(ClaudeColors.sidebar(scheme))
                    .transition(.opacity)
                    .zIndex(0)
            }
        }
        .background(ClaudeColors.sidebar(scheme).ignoresSafeArea())
        .animation(.spring(response: 0.32, dampingFraction: 0.88), value: store.sidebarVisible)
        .sheet(isPresented: $modelSheet) { ModelSheet() }
        .tint(ClaudeColors.accent)
        .onAppear {
            if ProcessInfo.processInfo.arguments.contains("--settings-snapshot") {
                store.navigate(.settings)
            }
        }
    }

    private var destination: some View {
        Group {
            switch store.destination {
            case .chat: ChatScreen(openModels: { modelSheet = true })
            case .chats: ChatsListScreen()
            case .projects: ProjectsScreen()
            case .project(let id): ProjectDetailScreen(projectID: id)
            case .artifacts: ArtifactsScreen()
            case .cowork: CoworkScreen()
            case .code: CodeScreen()
            case .tasks: TasksScreen()
            case .connectors: ConnectorsScreen()
            case .settings: SettingsScreen()
            }
        }
    }

    private func closeDrawer() { withAnimation(.spring(response: 0.32, dampingFraction: 0.88)) { store.sidebarVisible = false } }
}

struct AppHeader: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @State private var renameText = ""
    @State private var renameOpen = false
    @State private var projectPicker = false
    @State private var deleteConfirmation = false

    var body: some View {
        HStack(spacing: 9) {
            RoundIconButton(symbol: "line.3.horizontal.decrease", background: true) {
                store.sidebarVisible = true
            }
            .accessibilityLabel("Open sidebar")
            VStack(spacing: 3) {
                if let conversation = store.activeConversation {
                    Text(conversation.title)
                        .font(.system(size: 16, weight: .semibold))
                        .lineLimit(1)
                    Text(store.isDemoMode ? "Local" : "Cloud")
                        .font(.system(size: 13.5))
                        .foregroundStyle(ClaudeColors.muted(scheme))
                } else {
                    Text("Claude").font(ClaudeFont.heading(25))
                }
            }
            .frame(maxWidth: .infinity)
            .foregroundStyle(ClaudeColors.text(scheme))
            if store.activeConversation != nil {
                Button {
                    if store.isSending { store.stopResponse() }
                    else { store.newChat() }
                } label: {
                    ZStack {
                        Circle().stroke(ClaudeColors.stroke(scheme), lineWidth: 2.3)
                            .frame(width: 29, height: 29)
                        if store.isSending {
                            ProgressView().controlSize(.small)
                        } else {
                            Circle().trim(from: 0, to: 0.78)
                                .stroke(ClaudeColors.muted(scheme), style: StrokeStyle(lineWidth: 2.4, lineCap: .round))
                                .rotationEffect(.degrees(-90))
                                .frame(width: 29, height: 29)
                        }
                    }
                    .frame(width: 45, height: 45)
                    .background(ClaudeColors.elevated(scheme), in: Circle())
                    .overlay(Circle().stroke(ClaudeColors.stroke(scheme), lineWidth: 0.8))
                }
                .accessibilityLabel(store.isSending ? "Stop response" : "New chat")
                conversationMenu.frame(width: 46, height: 46)
                    .background(ClaudeColors.elevated(scheme), in: Circle())
                    .overlay(Circle().stroke(ClaudeColors.stroke(scheme), lineWidth: 0.8))
                    .foregroundStyle(ClaudeColors.text(scheme))
            } else {
                Button { store.newChat(incognito: !store.incognito) } label: {
                    Image(systemName: store.incognito ? "eye.slash.fill" : "theatermasks")
                        .font(.system(size: 18, weight: .light))
                        .frame(width: 45, height: 45)
                        .foregroundStyle(store.incognito ? ClaudeColors.accent : ClaudeColors.text(scheme))
                        .background(ClaudeColors.elevated(scheme), in: Circle())
                }
                .accessibilityLabel(store.incognito ? "Disable incognito" : "Incognito chat")
            }
        }
        .padding(.horizontal, 17)
        .padding(.top, 3)
        .frame(height: 64)
        .alert("Rename conversation", isPresented: $renameOpen) {
            TextField("Conversation title", text: $renameText)
            Button("Save") { if let id = store.currentID { store.rename(id, to: renameText) } }
            Button("Cancel", role: .cancel) {}
        }
        .confirmationDialog("Delete this conversation?", isPresented: $deleteConfirmation) {
            Button("Delete conversation", role: .destructive) { if let id = store.currentID { store.delete(id) } }
        }
        .sheet(isPresented: $projectPicker) {
            NavigationStack {
                List {
                    Button("None") { if let id = store.currentID { store.addToProject(id, projectID: nil) }; projectPicker = false }
                    ForEach(store.projects) { project in
                        Button(project.name) { if let id = store.currentID { store.addToProject(id, projectID: project.id) }; projectPicker = false }
                    }
                }
                .navigationTitle("Add to project")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { projectPicker = false } } }
            }
            .presentationDetents([.medium, .large])
        }
    }

    private var conversationMenu: some View {
        Menu {
            if let conversation = store.activeConversation {
                Button { renameText = conversation.title; renameOpen = true } label: { Label("Rename", systemImage: "pencil") }
                Button { store.toggleStar(conversation.id) } label: { Label(conversation.starred ? "Unstar" : "Star", systemImage: "star") }
                Button { projectPicker = true } label: { Label("Add to project", systemImage: "folder") }
                ShareLink(item: conversation.messages.map { "\($0.role == .user ? "You" : "Claude"): \($0.text)" }.joined(separator: "\n\n")) {
                    Label("Share conversation", systemImage: "square.and.arrow.up")
                }
                Divider()
                Button(role: .destructive) { deleteConfirmation = true } label: { Label("Delete", systemImage: "trash") }
            }
        } label: {
            Image(systemName: "ellipsis")
                .font(.system(size: 19, weight: .medium))
                .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .accessibilityLabel("Conversation options")
    }
}

struct ChatScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    var openModels: () -> Void
    @State private var draft = ""
    @State private var pendingAttachments: [ChatAttachment] = []

    var body: some View {
        VStack(spacing: 0) {
            AppHeader()
            if let conversation = store.activeConversation {
                conversationContent(conversation)
            } else {
                emptyConversation
            }
            if let error = store.lastError {
                HStack(spacing: 12) {
                    Image(systemName: "exclamationmark.triangle.fill")
                    Text(error).font(.system(size: 12.5))
                    Spacer()
                    Button("Retry") { store.retryLastTurn() }
                        .fontWeight(.semibold)
                    Button { store.lastError = nil } label: { Image(systemName: "xmark") }
                }
                .foregroundStyle(ClaudeColors.accent)
                .padding(12)
                .background(ClaudeColors.elevated(scheme), in: RoundedRectangle(cornerRadius: 12))
                .padding(.horizontal, 18)
            }
            ChatComposer(text: $draft, attachments: $pendingAttachments, disabled: store.isSending, openModels: openModels) {
                let copied = pendingAttachments
                let message = draft
                pendingAttachments = []
                draft = ""
                store.send(message, attachments: copied)
            }
        }
        .background(ClaudeColors.background(scheme))
    }

    private var emptyConversation: some View {
        VStack(spacing: 0) {
            if store.incognito {
                HStack(spacing: 9) {
                    Image(systemName: "eye.slash")
                    Text("Incognito chat")
                    Spacer()
                    Text("Not saved").foregroundStyle(ClaudeColors.muted(scheme))
                }
                .font(.system(size: 13))
                .padding(.horizontal, 18)
                .frame(height: 45)
                .background(ClaudeColors.elevated(scheme), in: RoundedRectangle(cornerRadius: 14))
                .padding(.horizontal, 16)
                .padding(.top, 5)
            } else {
                Button { store.navigate(.settings) } label: {
                    HStack(spacing: 12) {
                        Text("Set up live Claude")
                            .foregroundStyle(ClaudeColors.text(scheme))
                        Spacer()
                        Text("Connect")
                            .foregroundStyle(ClaudeColors.brightBlue)
                    }
                    .font(.system(size: 14))
                    .padding(.horizontal, 17)
                    .frame(height: 43)
                    .overlay(RoundedRectangle(cornerRadius: 15).stroke(ClaudeColors.stroke(scheme), lineWidth: 0.8))
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 14)
                .padding(.top, 5)
            }
            Spacer(minLength: 10)
            VStack(spacing: 20) {
                ClaudeMark(size: 40)
                Text(greeting)
                    .font(ClaudeFont.heading(25))
                    .kerning(-0.5)
                    .minimumScaleFactor(0.8)
                    .lineLimit(2)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(ClaudeColors.text(scheme))
                    .padding(.horizontal, 12)
            }
            .offset(y: 46)
            Spacer(minLength: 10)
        }
    }

    private var greeting: String {
        let hour = Calendar.current.component(.hour, from: .now)
        if hour < 12 { return "How can I help you this morning?" }
        if hour < 17 { return "How can I help you this afternoon?" }
        return "How can I help you this evening?"
    }

    private func conversationContent(_ conversation: Conversation) -> some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 25) {
                    if conversation.incognito {
                        Label("Incognito chat · Not saved", systemImage: "eye.slash")
                            .font(.system(size: 12))
                            .foregroundStyle(ClaudeColors.muted(scheme))
                            .frame(maxWidth: .infinity)
                    }
                    ForEach(conversation.messages) { message in
                        ChatMessageView(message: message, onRegenerate: { store.regenerateLastResponse() })
                            .id(message.id)
                    }
                    if store.isSending && !conversation.messages.contains(where: { $0.role == .assistant && $0.text.isEmpty }) {
                        HStack(spacing: 10) {
                            ClaudeMark(size: 24)
                            Text("Thinking...")
                                .font(ClaudeFont.serif(18))
                                .foregroundStyle(ClaudeColors.muted(scheme))
                        }
                        .id("thinking")
                    }
                    if conversation.messages.contains(where: { $0.role == .assistant && !$0.text.isEmpty }) {
                        HStack(alignment: .center, spacing: 5) {
                            ClaudeMark(size: 28)
                            Spacer()
                            Text("Claude is AI and can make mistakes.\nPlease double-check responses.")
                                .font(.system(size: 12.5))
                                .foregroundStyle(ClaudeColors.muted(scheme))
                                .multilineTextAlignment(.trailing)
                        }
                        .padding(.top, 0)
                    }
                }
                .padding(.horizontal, 19)
                .padding(.top, 24)
                .padding(.bottom, 25)
            }
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: conversation.messages.count) { _, _ in
                if let id = conversation.messages.last?.id { withAnimation(.easeOut(duration: 0.2)) { proxy.scrollTo(id, anchor: .bottom) } }
            }
            .onChange(of: store.isSending) { _, sending in
                if sending { withAnimation { proxy.scrollTo("thinking", anchor: .bottom) } }
                else if let id = conversation.messages.last?.id { withAnimation { proxy.scrollTo(id, anchor: .bottom) } }
            }
        }
    }
}

struct ChatMessageView: View {
    @Environment(\.colorScheme) private var scheme
    let message: ChatMessage
    var onRegenerate: () -> Void = {}
    @State private var showFeedback = false
    @State private var showSpeak = false
    @State private var isLiked = false
    @State private var isDisliked = false
    private var isUser: Bool { message.role == .user }

    var body: some View {
        HStack(alignment: .top, spacing: 0) {
            if isUser { Spacer(minLength: 30) }
            VStack(alignment: .leading, spacing: 16) {
                ForEach(message.attachments) { attachment in
                    if attachment.kind == .image, let data = attachment.data, let image = UIImage(data: data) {
                        Image(uiImage: image)
                            .resizable().scaledToFit()
                            .frame(maxWidth: 260, maxHeight: 250)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                    } else {
                        Label(attachment.name, systemImage: "doc.text")
                            .font(.system(size: 13))
                            .padding(11)
                            .background(ClaudeColors.elevated(scheme), in: RoundedRectangle(cornerRadius: 11))
                    }
                }
                if !message.text.isEmpty {
                    if isUser {
                        Text(message.text)
                            .font(.system(size: 16))
                            .lineSpacing(4)
                            .foregroundStyle(ClaudeColors.text(scheme))
                            .textSelection(.enabled)
                    } else {
                        RichMessageText(text: message.text)
                    }
                } else if !isUser {
                    HStack(spacing: 7) {
                        ProgressView().controlSize(.mini)
                        Text("Claude is thinking")
                            .font(ClaudeFont.serif(16))
                            .foregroundStyle(ClaudeColors.muted(scheme))
                    }
                }
                if !isUser && !message.text.isEmpty {
                    HStack(spacing: 22) {
                        action("square.on.square", "Copy") { UIPasteboard.general.string = message.text }
                        action("speaker.wave.2", "Read aloud") { showSpeak = true }
                        Menu {
                            ShareLink(item: message.text) { Label("Share", systemImage: "square.and.arrow.up") }
                            Button { onRegenerate() } label: { Label("Regenerate", systemImage: "arrow.clockwise") }
                            Button { isLiked = true; isDisliked = false } label: { Label("Good response", systemImage: "hand.thumbsup") }
                            Button { isDisliked = true; isLiked = false; showFeedback = true } label: { Label("Bad response", systemImage: "hand.thumbsdown") }
                        } label: {
                            Image(systemName: "ellipsis").accessibilityLabel("More message actions")
                        }
                    }
                    .font(.system(size: 14))
                    .foregroundStyle(ClaudeColors.muted(scheme))
                    .padding(.top, 1)
                }
            }
            .padding(isUser ? 14 : 0)
            .background(isUser ? ClaudeColors.bubble(scheme) : .clear, in: RoundedRectangle(cornerRadius: 20))
            if !isUser { Spacer(minLength: 0) }
        }
        .sheet(isPresented: $showFeedback) {
            VStack(spacing: 18) {
                SheetHandle()
                Text("Feedback").font(.system(size: 20, weight: .semibold))
                Text("Thanks for your feedback. This recreation stores reactions only in the current session.")
                    .font(.system(size: 15))
                    .multilineTextAlignment(.center)
                    .foregroundStyle(ClaudeColors.muted(scheme))
                Button("Done") { showFeedback = false }
                    .buttonStyle(.borderedProminent).tint(ClaudeColors.accent)
            }
            .padding(26)
            .presentationDetents([.medium])
        }
        .sheet(isPresented: $showSpeak) {
            SpeechPlaybackSheet(text: message.text)
                .presentationDetents([.medium])
        }
    }

    private func action(_ icon: String, _ title: String, perform: @escaping () -> Void) -> some View {
        Button(action: perform) { Image(systemName: icon).accessibilityLabel(title) }
            .buttonStyle(.plain)
    }
}

struct ModelSheet: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @Environment(\.dismiss) private var dismiss
    @State private var showingMore = false

    var body: some View {
        VStack(spacing: 0) {
            SheetHandle()
            HStack {
                RoundIconButton(symbol: "xmark") { dismiss() }
                Spacer()
                Text(showingMore ? "More models" : "Select model")
                    .font(.system(size: 17, weight: .semibold))
                Spacer()
                Color.clear.frame(width: 46, height: 46)
            }
            .padding(.horizontal, 14)
            ScrollView {
                VStack(spacing: 0) {
                    ForEach(showingMore ? ClaudeModel.all : Array(ClaudeModel.all.prefix(3))) { model in
                        Button {
                            store.chooseModel(model)
                            dismiss()
                        } label: {
                            HStack(spacing: 12) {
                                VStack(alignment: .leading, spacing: 5) {
                                    HStack(spacing: 7) {
                                        Text(model.name).font(.system(size: 16))
                                        if model.id.contains("opus") || model.id.contains("fable") {
                                            Text("Pro").font(.system(size: 12, weight: .semibold))
                                                .foregroundStyle(ClaudeColors.brightBlue)
                                                .padding(.horizontal, 7).padding(.vertical, 3)
                                                .background(ClaudeColors.brightBlue.opacity(0.13), in: Capsule())
                                        }
                                    }
                                    Text(model.subtitle)
                                        .font(.system(size: 12.5))
                                        .foregroundStyle(ClaudeColors.muted(scheme))
                                }
                                Spacer()
                                if model.id == store.selectedModel.id {
                                    Image(systemName: "checkmark")
                                        .font(.system(size: 17, weight: .semibold))
                                        .foregroundStyle(ClaudeColors.brightBlue)
                                }
                            }
                            .foregroundStyle(ClaudeColors.text(scheme))
                            .padding(.vertical, 13)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                    Rectangle().fill(ClaudeColors.stroke(scheme)).frame(height: 1).padding(.vertical, 11)
                    Toggle(isOn: $store.thinkEnabled) {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Adaptive thinking").font(.system(size: 16))
                            Text("Thinks for more complex tasks")
                                .font(.system(size: 12.5))
                                .foregroundStyle(ClaudeColors.muted(scheme))
                        }
                    }
                    .tint(ClaudeColors.brightBlue)
                    .padding(.vertical, 10)
                    Rectangle().fill(ClaudeColors.stroke(scheme)).frame(height: 1).padding(.vertical, 10)
                    Button { withAnimation { showingMore.toggle() } } label: {
                        HStack {
                            Text(showingMore ? "Fewer models" : "More models")
                            Spacer()
                            Image(systemName: showingMore ? "chevron.up" : "chevron.right")
                                .foregroundStyle(ClaudeColors.muted(scheme))
                        }
                        .font(.system(size: 16))
                        .foregroundStyle(ClaudeColors.text(scheme))
                        .frame(height: 46)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, 26)
            }
        }
        .background(ClaudeColors.background(scheme))
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.hidden)
    }
}

struct RichMessageText: View {
    @Environment(\.colorScheme) private var scheme
    let text: String
    @AppStorage("claudere-reading-size") private var readingSize = 18.0
    private var parts: [String] { text.components(separatedBy: "```") }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            ForEach(Array(parts.enumerated()), id: \.offset) { index, part in
                if index.isMultiple(of: 2) {
                    if !part.isEmpty {
                        Text((try? AttributedString(markdown: part)) ?? AttributedString(part))
                            .font(.system(size: CGFloat(readingSize)))
                            .lineSpacing(6)
                            .foregroundStyle(ClaudeColors.text(scheme))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                } else {
                    let lines = part.split(separator: "\n", maxSplits: 1, omittingEmptySubsequences: false)
                    let language = lines.first.map(String.init) ?? "Code"
                    let code = lines.count > 1 ? String(lines[1]) : part
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            Text(language.isEmpty ? "Code" : language)
                            Spacer()
                            Button { UIPasteboard.general.string = code } label: { Label("Copy", systemImage: "square.on.square") }
                        }
                        .font(.system(size: 12))
                        .foregroundStyle(ClaudeColors.muted(scheme))
                        .padding(12)
                        Rectangle().fill(ClaudeColors.stroke(scheme)).frame(height: 1)
                        ScrollView(.horizontal, showsIndicators: false) {
                            Text(code)
                                .font(.system(size: 13, design: .monospaced))
                                .textSelection(.enabled)
                                .padding(13)
                        }
                    }
                    .background(ClaudeColors.elevated(scheme), in: RoundedRectangle(cornerRadius: 13))
                }
            }
        }
    }
}
