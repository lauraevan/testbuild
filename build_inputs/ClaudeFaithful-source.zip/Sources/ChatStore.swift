import SwiftUI

@MainActor
final class ChatStore: ObservableObject {
    @Published var conversations: [Conversation] = []
    @Published var projects: [ClaudeProject] = []
    @Published var currentID: UUID?
    @Published var selectedModel: ClaudeModel = .defaultModel
    @Published var destination: NavigationDestination = .chat
    @Published var sidebarVisible = false
    @Published var isSending = false
    @Published var lastError: String?
    @Published var incognito = false
    @Published var nextProjectID: UUID?
    @Published var webSearchEnabled = false
    @Published var thinkEnabled = false

    private let conversationsKey = "claudere-conversations-v1"
    private let projectsKey = "claudere-projects-v1"
    private let modelKey = "claudere-selectedmodel-v1"

    init() {
        if let data = UserDefaults.standard.data(forKey: conversationsKey),
           let restored = try? JSONDecoder().decode([Conversation].self, from: data) {
            conversations = restored.filter { !$0.incognito }
        }
        if let data = UserDefaults.standard.data(forKey: projectsKey),
           let restored = try? JSONDecoder().decode([ClaudeProject].self, from: data) {
            projects = restored
        }
        if let modelID = UserDefaults.standard.string(forKey: modelKey),
           let model = ClaudeModel.all.first(where: { $0.id == modelID }) {
            selectedModel = model
        }
    }

    var activeConversation: Conversation? {
        conversations.first(where: { $0.id == currentID })
    }
    var sortedConversations: [Conversation] {
        conversations.sorted { $0.updatedAt > $1.updatedAt }
    }
    var isDemoMode: Bool { APIKeyVault.read().map { $0.isEmpty } ?? true }

    func persist() {
        if let data = try? JSONEncoder().encode(conversations.filter { !$0.incognito }) {
            UserDefaults.standard.set(data, forKey: conversationsKey)
        }
        if let data = try? JSONEncoder().encode(projects) {
            UserDefaults.standard.set(data, forKey: projectsKey)
        }
    }

    func chooseModel(_ model: ClaudeModel) {
        selectedModel = model
        UserDefaults.standard.set(model.id, forKey: modelKey)
    }
    func newChat(incognito: Bool = false) {
        currentID = nil
        destination = .chat
        self.incognito = incognito
        nextProjectID = nil
        sidebarVisible = false
        lastError = nil
    }
    func openChat(_ id: UUID) {
        currentID = id
        destination = .chat
        incognito = conversations.first(where: { $0.id == id })?.incognito ?? false
        sidebarVisible = false
        lastError = nil
    }
    func navigate(_ destination: NavigationDestination) {
        self.destination = destination
        sidebarVisible = false
    }
    func toggleStar(_ id: UUID) {
        guard let index = conversations.firstIndex(where: { $0.id == id }) else { return }
        conversations[index].starred.toggle()
        persist()
    }
    func rename(_ id: UUID, to title: String) {
        guard let index = conversations.firstIndex(where: { $0.id == id }) else { return }
        let value = title.trimmingCharacters(in: .whitespacesAndNewlines)
        if !value.isEmpty { conversations[index].title = value }
        persist()
    }
    func delete(_ id: UUID) {
        conversations.removeAll { $0.id == id }
        if currentID == id { newChat() }
        persist()
    }
    func addToProjectForNextChat(_ id: UUID) { nextProjectID = id }
    func addProject(name: String, details: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        projects.append(.init(name: trimmed, details: details))
        persist()
    }
    func updateProject(_ project: ClaudeProject) {
        guard let index = projects.firstIndex(where: { $0.id == project.id }) else { return }
        projects[index] = project
        persist()
    }
    func addToProject(_ conversationID: UUID, projectID: UUID?) {
        guard let index = conversations.firstIndex(where: { $0.id == conversationID }) else { return }
        conversations[index].projectID = projectID
        persist()
    }
    func deleteProject(_ id: UUID) {
        projects.removeAll { $0.id == id }
        for index in conversations.indices where conversations[index].projectID == id {
            conversations[index].projectID = nil
        }
        navigate(.projects)
        persist()
    }

    // Regenerate only the last assistant response, retaining the user's final prompt.
    func regenerateLastResponse() {
        guard !isSending, let id = currentID,
              let idx = conversations.firstIndex(where: { $0.id == id }) else { return }
        if conversations[idx].messages.last?.role == .assistant {
            conversations[idx].messages.removeLast()
        }
        guard conversations[idx].messages.last?.role == .user else { return }
        startResponse(in: id)
    }

    func retryLastTurn() {
        lastError = nil
        regenerateLastResponse()
    }

    func send(_ rawText: String, attachments: [ChatAttachment] = []) {
        let text = rawText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard (!text.isEmpty || !attachments.isEmpty) && !isSending else { return }
        let conversationID: UUID
        if let id = currentID, let index = conversations.firstIndex(where: { $0.id == id }) {
            conversationID = id
            conversations[index].messages.append(.init(role: .user, text: text, attachments: attachments))
            conversations[index].updatedAt = .now
        } else {
            let title = String((text.isEmpty ? (attachments.first?.name ?? "New conversation") : text).prefix(55))
            let conversation = Conversation(title: title, messages: [.init(role: .user, text: text, attachments: attachments)], incognito: incognito, projectID: nextProjectID)
            nextProjectID = nil
            conversationID = conversation.id
            conversations.insert(conversation, at: 0)
            currentID = conversationID
        }
        destination = .chat
        startResponse(in: conversationID)
    }

    private func startResponse(in conversationID: UUID) {
        guard !isSending else { return }
        lastError = nil
        isSending = true
        persist()
        let model = selectedModel
        let apiKey = APIKeyVault.read()
        let messages = conversations.first(where: { $0.id == conversationID })?.messages ?? []
        let projectID = conversations.first(where: { $0.id == conversationID })?.projectID
        let instructions = projects.first(where: { $0.id == projectID })?.instructions ?? ""
        let thinking = thinkEnabled
        let search = webSearchEnabled
        let style = UserDefaults.standard.string(forKey: "claudere-writing-style") ?? "Normal"

        Task {
            do {
                if let apiKey, !apiKey.isEmpty {
                    // Placeholder lets the reader watch real response tokens arrive.
                    let responseID = UUID()
                    if let index = conversations.firstIndex(where: { $0.id == conversationID }) {
                        conversations[index].messages.append(.init(id: responseID, role: .assistant, text: ""))
                    }
                    try await ClaudeAPI.stream(messages: messages, model: model, apiKey: apiKey,
                                               instructions: instructions, thinking: thinking, search: search, style: style) { fragment in
                        guard let ci = self.conversations.firstIndex(where: { $0.id == conversationID }),
                              let mi = self.conversations[ci].messages.firstIndex(where: { $0.id == responseID }) else { return }
                        self.conversations[ci].messages[mi].text += fragment
                        self.conversations[ci].updatedAt = .now
                    }
                    if let ci = conversations.firstIndex(where: { $0.id == conversationID }),
                       let mi = conversations[ci].messages.firstIndex(where: { $0.id == responseID }),
                       conversations[ci].messages[mi].text.isEmpty {
                        conversations[ci].messages[mi].text = "No response was returned."
                    }
                } else {
                    try await Task.sleep(for: .milliseconds(650))
                    let text = messages.last(where: { $0.role == .user })?.text ?? ""
                    if let index = conversations.firstIndex(where: { $0.id == conversationID }) {
                        conversations[index].messages.append(.init(role: .assistant, text: DemoResponder.reply(to: text)))
                    }
                }
            } catch {
                lastError = error.localizedDescription
                if let ci = conversations.firstIndex(where: { $0.id == conversationID }),
                   conversations[ci].messages.last?.role == .assistant,
                   conversations[ci].messages.last?.text.isEmpty == true {
                    conversations[ci].messages.removeLast()
                }
            }
            isSending = false
            persist()
        }
    }
}
