import SwiftUI
import Speech
import AVFoundation

@MainActor
final class SpeechCapture: ObservableObject {
    @Published var transcript = ""
    @Published var isListening = false
    @Published var failure: String?

    private let audioEngine = AVAudioEngine()
    private let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "en_US"))
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?

    func start() async {
        guard !isListening else { return }
        let authorization = await withCheckedContinuation { continuation in
            SFSpeechRecognizer.requestAuthorization { status in
                continuation.resume(returning: status)
            }
        }
        guard authorization == .authorized else {
            failure = "Allow Speech Recognition in iOS Settings to dictate a message."
            return
        }
        let microphoneGranted = await withCheckedContinuation { continuation in
            AVAudioApplication.requestRecordPermission { granted in
                continuation.resume(returning: granted)
            }
        }
        guard microphoneGranted else {
            failure = "Allow Microphone access in iOS Settings to dictate a message."
            return
        }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.record, mode: .measurement, options: .duckOthers)
            try session.setActive(true, options: .notifyOthersOnDeactivation)
            let request = SFSpeechAudioBufferRecognitionRequest()
            request.shouldReportPartialResults = true
            recognitionRequest = request
            let input = audioEngine.inputNode
            let format = input.outputFormat(forBus: 0)
            input.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
                request.append(buffer)
            }
            audioEngine.prepare()
            try audioEngine.start()
            isListening = true
            recognitionTask = recognizer?.recognitionTask(with: request) { [weak self] result, error in
                Task { @MainActor in
                    if let result { self?.transcript = result.bestTranscription.formattedString }
                    if let error { self?.failure = error.localizedDescription; self?.stop() }
                }
            }
        } catch {
            failure = error.localizedDescription
            stop()
        }
    }

    func stop() {
        if audioEngine.isRunning {
            audioEngine.stop()
            audioEngine.inputNode.removeTap(onBus: 0)
        }
        recognitionRequest?.endAudio()
        recognitionTask?.cancel()
        recognitionRequest = nil
        recognitionTask = nil
        isListening = false
        try? AVAudioSession.sharedInstance().setActive(false)
    }
}

struct VoiceCaptureSheet: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme
    @StateObject private var speech = SpeechCapture()
    var completion: (String) -> Void

    var body: some View {
        VStack(spacing: 19) {
            Capsule().fill(.secondary.opacity(0.25)).frame(width: 36, height: 5).padding(.top, 10)
            Spacer()
            ClaudeMark(size: 54)
            Text(speech.isListening ? "Listening..." : "Voice dictation")
                .font(.system(size: 26, design: .serif))
            Text(speech.failure ?? (speech.transcript.isEmpty ? "Speak naturally. Your words will appear here." : speech.transcript))
                .font(.system(size: 14))
                .multilineTextAlignment(.center)
                .foregroundStyle(speech.failure == nil ? ClaudeColors.muted(scheme) : .red)
                .frame(minHeight: 46)
                .padding(.horizontal, 28)
            Spacer()
            Button {
                completion(speech.transcript)
                speech.stop()
                dismiss()
            } label: {
                Text("Use transcription")
                    .font(.system(size: 15, weight: .semibold))
                    .frame(maxWidth: .infinity)
                    .frame(height: 47)
            }
            .buttonStyle(.borderedProminent)
            .tint(ClaudeColors.accent)
            .disabled(speech.transcript.isEmpty)
            .padding(.horizontal, 25)
            Button("Cancel") { speech.stop(); dismiss() }
                .foregroundStyle(ClaudeColors.muted(scheme))
                .padding(.bottom, 15)
        }
        .background(ClaudeColors.background(scheme))
        .task { await speech.start() }
        .onDisappear { speech.stop() }
    }
}

@MainActor
final class SpeechPlayback: ObservableObject {
    private let synthesizer = AVSpeechSynthesizer()
    @Published var playing = false
    func start(_ text: String) {
        synthesizer.stopSpeaking(at: .immediate)
        let utterance = AVSpeechUtterance(string: text)
        utterance.rate = 0.49
        utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        synthesizer.speak(utterance)
        playing = true
    }
    func stop() {
        synthesizer.stopSpeaking(at: .immediate)
        playing = false
    }
}

struct SpeechPlaybackSheet: View {
    let text: String
    @StateObject private var playback = SpeechPlayback()
    @Environment(\.dismiss) private var dismiss
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        VStack(spacing: 22) {
            SheetHandle()
            Spacer()
            ClaudeMark(size: 56)
            Text("Read aloud").font(ClaudeFont.heading(26))
            Text(String(text.prefix(220)))
                .font(.system(size: 14))
                .lineLimit(5)
                .multilineTextAlignment(.center)
                .foregroundStyle(ClaudeColors.muted(scheme))
            Button(playback.playing ? "Stop playback" : "Play response") {
                if playback.playing { playback.stop() }
                else { playback.start(text) }
            }
            .buttonStyle(.borderedProminent).tint(ClaudeColors.accent)
            Spacer()
            Button("Done") { playback.stop(); dismiss() }
                .padding(.bottom, 16)
        }
        .padding(.horizontal, 25)
        .background(ClaudeColors.background(scheme))
        .onDisappear { playback.stop() }
    }
}
