import SwiftUI

struct SettingsScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @AppStorage("claudere-appearance") private var appearance = "Dark"
    @State private var apiKeyInput = ""
    @State private var hasStoredKey = false
    @State private var showKey = false
    @State private var showDeleteAlert = false

    var body: some View {
        VStack(spacing: 0) {
            ScreenBar(title: "Settings")
            Form {
                Section {
                    HStack(spacing: 13) {
                        Text("B")
                            .font(.system(size: 23, weight: .medium, design: .serif))
                            .frame(width: 51, height: 51)
                            .background(ClaudeColors.bubble(scheme), in: Circle())
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Local profile").font(.system(size: 16, weight: .medium))
                            Text("Independent Claude-style recreation")
                                .font(.system(size: 12)).foregroundStyle(ClaudeColors.muted(scheme))
                        }
                    }
                    .padding(.vertical, 5)
                }
                Section("Appearance") {
                    Picker("Theme", selection: $appearance) {
                        Text("System").tag("System")
                        Text("Light").tag("Light")
                        Text("Dark").tag("Dark")
                    }
                }
                Section {
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Anthropic API key")
                            Text(hasStoredKey ? "Configured · live Claude responses enabled" : "Not configured · local demo responses")
                                .font(.system(size: 12))
                                .foregroundStyle(ClaudeColors.muted(scheme))
                        }
                        Spacer()
                        Image(systemName: hasStoredKey ? "checkmark.circle.fill" : "key")
                            .foregroundStyle(hasStoredKey ? Color.green : ClaudeColors.muted(scheme))
                    }
                    HStack {
                        Group {
                            if showKey { TextField("sk-ant-…", text: $apiKeyInput) }
                            else { SecureField("sk-ant-…", text: $apiKeyInput) }
                        }
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        Button { showKey.toggle() } label: {
                            Image(systemName: showKey ? "eye.slash" : "eye")
                        }
                        .buttonStyle(.plain)
                    }
                    Button("Save API key") {
                        APIKeyVault.write(apiKeyInput.trimmingCharacters(in: .whitespacesAndNewlines))
                        hasStoredKey = APIKeyVault.read() != nil
                        apiKeyInput = ""
                    }
                    .disabled(apiKeyInput.isEmpty)
                    if hasStoredKey {
                        Button("Remove saved key", role: .destructive) {
                            APIKeyVault.write("")
                            hasStoredKey = false
                        }
                    }
                } header: { Text("Live chat") } footer: {
                    Text("Your API key is stored in the iOS Keychain, never in the project source. Requests go directly from your device to api.anthropic.com. API usage may be billed by Anthropic. This does not use your Claude app subscription.")
                }
                Section("Capabilities") {
                    Toggle("Adaptive thinking", isOn: $store.thinkEnabled)
                    Toggle("Web search", isOn: $store.webSearchEnabled)
                    Text("These options use supported Claude API parameters when your key is configured. Web search may incur separate tool charges.")
                        .font(.system(size: 12))
                        .foregroundStyle(ClaudeColors.muted(scheme))
                }
                Section("Data & privacy") {
                    Text("Conversations and projects are stored locally on this device. Incognito chats are not written to disk.")
                        .font(.system(size: 13))
                    Button("Delete all local conversations", role: .destructive) { showDeleteAlert = true }
                }
                Section("About") {
                    HStack {
                        Text("Version")
                        Spacer()
                        Text("0.3.0").foregroundStyle(ClaudeColors.muted(scheme))
                    }
                    Text("Unofficial educational UI recreation. Not affiliated with or endorsed by Anthropic. No original app binary, proprietary frontend source, or private APIs are included.")
                        .font(.system(size: 12))
                        .foregroundStyle(ClaudeColors.muted(scheme))
                }
            }
            .scrollContentBackground(.hidden)
            .background(ClaudeColors.background(scheme))
            .tint(ClaudeColors.accent)
        }
        .onAppear { hasStoredKey = APIKeyVault.read() != nil }
        .confirmationDialog("Delete all saved conversations?", isPresented: $showDeleteAlert) {
            Button("Delete conversations", role: .destructive) {
                store.conversations.removeAll()
                store.persist()
                store.newChat()
            }
        }
    }
}
