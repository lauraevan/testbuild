import SwiftUI
import UIKit

struct CoworkScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @State private var addProject = false
    @State private var projectName = ""
    @State private var projectDescription = ""
    var body: some View {
        VStack(spacing: 0) {
            ScreenBar(title: "Cowork", rightSymbol: "plus") { addProject = true }
            ScrollView {
                VStack(alignment: .leading, spacing: 23) {
                    VStack(alignment: .leading, spacing: 13) {
                        ClaudeMark(size: 42)
                        Text("Let's work on something").font(ClaudeFont.heading(28))
                        Text("Organize projects and plan work using your local chats. Live Claude Cowork sessions and computer control are not connected to this recreation.")
                            .font(.system(size: 14.5)).foregroundStyle(ClaudeColors.muted(scheme))
                            .fixedSize(horizontal: false, vertical: true)
                        Button { store.newChat() } label: {
                            Label("Start a chat", systemImage: "plus")
                                .font(.system(size: 15, weight: .medium)).padding(.horizontal, 18).frame(height: 44)
                                .foregroundStyle(.white).background(ClaudeColors.accent, in: Capsule())
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(22)
                    .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 23))
                    Text("Your workspace").font(.system(size: 20, weight: .semibold))
                    if store.projects.isEmpty {
                        emptyCard("No projects yet", "Create a workspace for your ideas, files, and conversations.", icon: "folder")
                    } else {
                        ForEach(store.projects) { project in
                            Button { store.navigate(.project(project.id)) } label: {
                                HStack(spacing: 14) {
                                    Image(systemName: "folder.fill").foregroundStyle(ClaudeColors.accent)
                                        .font(.system(size: 20)).frame(width: 40, height: 40)
                                        .background(ClaudeColors.accent.opacity(0.1), in: RoundedRectangle(cornerRadius: 12))
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(project.name).font(.system(size: 16, weight: .medium))
                                        Text(project.details.isEmpty ? "Local project" : project.details)
                                            .font(.system(size: 12)).foregroundStyle(ClaudeColors.muted(scheme)).lineLimit(1)
                                    }
                                    Spacer(); Image(systemName: "chevron.right").font(.system(size: 12)).foregroundStyle(.secondary)
                                }
                                .padding(15).background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 16))
                            }.buttonStyle(.plain)
                        }
                    }
                    HStack {
                        Text("Local reminders").font(.system(size: 20, weight: .semibold))
                        Spacer()
                        Button("See all") { store.navigate(.tasks) }.font(.system(size: 13))
                    }
                    if store.reminders.isEmpty {
                        emptyCard("No scheduled reminders", "Set local reminders for project deadlines.", icon: "calendar.badge.clock")
                    } else {
                        ForEach(store.reminders.prefix(4)) { reminder in
                            HStack {
                                Image(systemName: reminder.completed ? "checkmark.circle.fill" : "circle")
                                Text(reminder.title).lineLimit(1)
                                Spacer()
                                Text(reminder.scheduledAt, style: .date).font(.system(size: 12)).foregroundStyle(.secondary)
                            }.font(.system(size: 14)).padding(14).background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 14))
                        }
                    }
                }
                .padding(19)
            }
        }
        .background(ClaudeColors.background(scheme))
        .alert("New project", isPresented: $addProject) {
            TextField("Project name", text: $projectName)
            TextField("Description", text: $projectDescription)
            Button("Create") { store.addProject(name: projectName, details: projectDescription); projectName = ""; projectDescription = "" }
            Button("Cancel", role: .cancel) {}
        }
    }
    private func emptyCard(_ title: String, _ subtitle: String, icon: String) -> some View {
        HStack(spacing: 14) {
            Image(systemName: icon).font(.system(size: 25)).foregroundStyle(ClaudeColors.accent)
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.system(size: 15, weight: .medium))
                Text(subtitle).font(.system(size: 12.5)).foregroundStyle(ClaudeColors.muted(scheme))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(19).background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 17))
    }
}

private struct Snippet: Identifiable {
    var id: String
    var title: String
    var code: String
}

struct CodeScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @State private var search = ""
    @State private var selected: Snippet?
    private var snippets: [Snippet] {
        store.sortedConversations.flatMap { conversation in
            conversation.messages.filter { $0.role == .assistant }.flatMap { message in
                let parts = message.text.components(separatedBy: "```")
                return parts.indices.filter { !$0.isMultiple(of: 2) }.map { index in
                    Snippet(id: "\(message.id)-\(index)", title: conversation.title, code: parts[index])
                }
            }
        }.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) || $0.code.localizedCaseInsensitiveContains(search) }
    }
    var body: some View {
        VStack(spacing: 0) {
            ScreenBar(title: "Claude Code", rightSymbol: "plus") { store.newChat() }
            ScrollView {
                VStack(alignment: .leading, spacing: 17) {
                    Text("Your coding workspace").font(ClaudeFont.heading(27))
                    Text("Browse code from local chats, copy snippets, and continue coding with a model connected through your API key.")
                        .font(.system(size: 14)).foregroundStyle(ClaudeColors.muted(scheme))
                    HStack(spacing: 10) {
                        Image(systemName: "magnifyingglass")
                        TextField("Search code", text: $search).textInputAutocapitalization(.never)
                    }
                    .font(.system(size: 14)).padding(13)
                    .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 12))
                    if snippets.isEmpty {
                        VStack(spacing: 16) {
                            Image(systemName: "chevron.left.forwardslash.chevron.right").font(.system(size: 40, weight: .thin))
                            Text("No code snippets yet").font(.system(size: 18, weight: .medium))
                            Text("Ask for code in a chat. Fenced code blocks will appear here.")
                                .font(.system(size: 14)).foregroundStyle(ClaudeColors.muted(scheme)).multilineTextAlignment(.center)
                            Button("New coding chat") { store.newChat() }
                                .buttonStyle(.borderedProminent).tint(ClaudeColors.accent)
                        }
                        .frame(maxWidth: .infinity).padding(32)
                        .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 21))
                    }
                    ForEach(snippets) { item in
                        Button { selected = item } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "curlybraces").foregroundStyle(ClaudeColors.accent)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(item.title).font(.system(size: 16, weight: .medium)).lineLimit(1)
                                    Text(item.code).font(.system(size: 12, design: .monospaced))
                                        .lineLimit(2).foregroundStyle(ClaudeColors.muted(scheme))
                                }
                                Spacer(); Image(systemName: "chevron.right").font(.system(size: 11))
                            }.padding(16).background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 15))
                        }.buttonStyle(.plain)
                    }
                    Link("Open official Claude Code documentation", destination: URL(string: "https://code.claude.com/docs/en/overview")!)
                        .font(.system(size: 13))
                    Text("This screen is a local code library. Remote Claude Code sessions need Anthropic's authenticated services.")
                        .font(.system(size: 12)).foregroundStyle(ClaudeColors.muted(scheme))
                }
                .padding(20)
            }
        }.background(ClaudeColors.background(scheme))
        .sheet(item: $selected) { item in
            NavigationStack {
                ScrollView {
                    Text(item.code).font(.system(size: 13, design: .monospaced)).textSelection(.enabled)
                        .frame(maxWidth: .infinity, alignment: .leading).padding(20)
                }.background(ClaudeColors.background(scheme))
                    .navigationTitle(item.title).navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarLeading) { Button("Done") { selected = nil } }
                        ToolbarItem(placement: .topBarTrailing) {
                            Button { UIPasteboard.general.string = item.code } label: { Image(systemName: "doc.on.doc") }
                        }
                        ToolbarItem(placement: .topBarTrailing) { ShareLink(item: item.code) { Image(systemName: "square.and.arrow.up") } }
                    }
            }
        }
    }
}

struct TasksScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @State private var adding = false
    @State private var title = ""
    @State private var notes = ""
    @State private var date = Date().addingTimeInterval(3600)
    @State private var repeatDaily = false
    private var sorted: [LocalReminder] { store.reminders.sorted { $0.scheduledAt < $1.scheduledAt } }
    var body: some View {
        VStack(spacing: 0) {
            ScreenBar(title: "Scheduled", rightSymbol: "plus") { adding = true }
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text("Your reminders").font(ClaudeFont.heading(28))
                    Text("Schedule notifications on this iPhone. These reminders do not run Claude autonomously or sync with Anthropic's Scheduled Tasks.")
                        .font(.system(size: 13.5)).foregroundStyle(ClaudeColors.muted(scheme))
                    Button { adding = true } label: {
                        HStack { Image(systemName: "plus"); Text("Create reminder"); Spacer(); Image(systemName: "chevron.right") }
                            .padding(16).foregroundStyle(ClaudeColors.text(scheme))
                            .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 16))
                    }
                    if sorted.isEmpty {
                        ContentUnavailableView("Nothing scheduled", systemImage: "calendar.badge.clock", description: Text("Create a one-off or repeating local reminder."))
                    }
                    ForEach(sorted) { reminder in
                        HStack(alignment: .top, spacing: 12) {
                            Button { store.toggleReminder(reminder.id) } label: {
                                Image(systemName: reminder.completed ? "checkmark.circle.fill" : "circle")
                                    .font(.system(size: 23)).foregroundStyle(reminder.completed ? ClaudeColors.accent : ClaudeColors.muted(scheme))
                            }
                            VStack(alignment: .leading, spacing: 5) {
                                Text(reminder.title).font(.system(size: 16, weight: .medium))
                                    .strikethrough(reminder.completed).lineLimit(2)
                                if !reminder.notes.isEmpty {
                                    Text(reminder.notes).font(.system(size: 12.5)).foregroundStyle(ClaudeColors.muted(scheme))
                                }
                                Text(reminder.scheduledAt, format: .dateTime.weekday().month().day().hour().minute())
                                    .font(.system(size: 12)).foregroundStyle(ClaudeColors.accent)
                                if reminder.repeatsDaily { Text("Repeats daily").font(.system(size: 12)).foregroundStyle(.secondary) }
                            }
                            Spacer()
                            Button(role: .destructive) { store.deleteReminder(reminder.id) } label: {
                                Image(systemName: "trash").font(.system(size: 15)).foregroundStyle(ClaudeColors.muted(scheme))
                            }
                        }
                        .padding(16).background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 16))
                    }
                }.padding(20)
            }
        }.background(ClaudeColors.background(scheme))
        .sheet(isPresented: $adding) {
            NavigationStack {
                Form {
                    Section("Reminder") {
                        TextField("What would you like to remember?", text: $title)
                        TextField("Notes (optional)", text: $notes, axis: .vertical).lineLimit(2...5)
                    }
                    Section("When") {
                        DatePicker("Notify me", selection: $date, in: Date()..., displayedComponents: [.date, .hourAndMinute])
                        Toggle("Repeat daily", isOn: $repeatDaily)
                    }
                    Section { Text("Local reminder notifications require permission in Settings → Notifications.").font(.system(size: 12)).foregroundStyle(.secondary) }
                }
                .navigationTitle("New reminder").navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) { Button("Cancel") { adding = false } }
                    ToolbarItem(placement: .topBarTrailing) { Button("Save") {
                        store.addReminder(title: title, notes: notes, date: date, repeatsDaily: repeatDaily)
                        title = ""; notes = ""; repeatDaily = false; adding = false
                    }.disabled(title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty) }
                }
            }
        }
    }
}

struct ConnectorsScreen: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    private let services: [(String,String,String)] = [
        ("envelope", "Gmail", "Email drafts and search"),
        ("folder", "Google Drive", "Files and documents"),
        ("calendar", "Google Calendar", "Schedules and meetings"),
        ("desktopcomputer", "Computer use", "Remote desktop sessions"),
        ("network", "MCP servers", "External tools and services")
    ]
    var body: some View {
        VStack(spacing: 0) {
            ScreenBar(title: "Connectors")
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("Connect your tools").font(ClaudeFont.heading(28))
                    Text("External account connectors cannot be authorized with an API key alone. The items below show the intended integrations without pretending they're connected.")
                        .font(.system(size: 13.5)).foregroundStyle(ClaudeColors.muted(scheme))
                    ForEach(Array(services.enumerated()), id: \.offset) { pair in
                        let item = pair.element
                        HStack(spacing: 13) {
                            Image(systemName: item.0).font(.system(size: 21)).frame(width: 34)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.1).font(.system(size: 16, weight: .medium))
                                Text(item.2).font(.system(size: 12)).foregroundStyle(ClaudeColors.muted(scheme))
                            }
                            Spacer()
                            Text("Unavailable").font(.system(size: 11)).foregroundStyle(ClaudeColors.muted(scheme))
                        }
                        .padding(17).background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 18))
                    }
                    Link("Learn about Claude integrations", destination: URL(string: "https://support.claude.com")!)
                        .font(.system(size: 14))
                }.padding(20)
            }
        }.background(ClaudeColors.background(scheme))
    }
}
