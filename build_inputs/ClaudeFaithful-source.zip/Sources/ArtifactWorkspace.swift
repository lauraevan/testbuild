import SwiftUI
import UIKit
import WebKit

struct ArtifactWorkspace: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @Environment(\.dismiss) private var dismiss
    let artifact: ArtifactEntry
    @State private var content = ""
    @State private var mode = "Preview"
    @State private var savedNotice = false
    private var savedID: UUID? {
        guard artifact.id.hasPrefix("saved:") else { return nil }
        return UUID(uuidString: String(artifact.id.dropFirst(6)))
    }
    private var isHTML: Bool {
        let lower = content.lowercased()
        return lower.contains("<html") || lower.contains("<!doctype html") || lower.contains("<body")
    }
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("View", selection: $mode) {
                    Text("Preview").tag("Preview")
                    Text("Code").tag("Code")
                }
                .pickerStyle(.segmented).padding(.horizontal, 17).padding(.top, 12)
                if mode == "Preview" {
                    if isHTML {
                        LocalHTMLPreview(html: content)
                            .padding(.top, 12)
                    } else {
                        ScrollView {
                            Text((try? AttributedString(markdown: content)) ?? AttributedString(content))
                                .font(.system(size: 16)).textSelection(.enabled)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(19)
                        }
                    }
                } else {
                    TextEditor(text: $content)
                        .font(.system(size: 13.5, design: .monospaced))
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                        .scrollContentBackground(.hidden)
                        .padding(14)
                }
            }
            .background(ClaudeColors.background(scheme).ignoresSafeArea())
            .navigationTitle(artifact.title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("Done") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        if let savedID { store.updateArtifact(savedID, content: content) }
                        else { store.saveArtifact(title: artifact.title, content: content) }
                        savedNotice = true
                    } label: { Image(systemName: "square.and.arrow.down") }
                    .accessibilityLabel("Save artifact locally")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    ShareLink(item: content) { Image(systemName: "square.and.arrow.up") }
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { UIPasteboard.general.string = content } label: { Image(systemName: "doc.on.doc") }
                }
            }
            .onAppear { content = artifact.body }
            .alert("Saved to local Artifacts", isPresented: $savedNotice) {
                Button("OK", role: .cancel) {}
            }
        }
    }
}

private struct LocalHTMLPreview: UIViewRepresentable {
    var html: String
    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        let preferences = WKWebpagePreferences()
        preferences.allowsContentJavaScript = false
        configuration.defaultWebpagePreferences = preferences
        configuration.websiteDataStore = .nonPersistent()
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.isOpaque = false
        webView.backgroundColor = .clear
        return webView
    }
    func updateUIView(_ uiView: WKWebView, context: Context) {
        // JavaScript is disabled and preview content never accesses the user's filesystem.
        uiView.loadHTMLString(html, baseURL: nil)
    }
}
