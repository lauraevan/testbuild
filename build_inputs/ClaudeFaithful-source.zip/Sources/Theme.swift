import SwiftUI

struct ClaudeColors {
    static let accent = Color(red: 0.79, green: 0.39, blue: 0.27)
    static func background(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.12, green: 0.115, blue: 0.109) : Color(red: 0.992, green: 0.989, blue: 0.978)
    }
    static func sidebar(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.15, green: 0.145, blue: 0.137) : Color(red: 0.967, green: 0.962, blue: 0.946)
    }
    static func surface(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.185, green: 0.179, blue: 0.170) : .white
    }
    static func bubble(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.225, green: 0.215, blue: 0.204) : Color(red: 0.943, green: 0.937, blue: 0.922)
    }
    static func text(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.95, green: 0.94, blue: 0.92) : Color(red: 0.17, green: 0.17, blue: 0.16)
    }
    static func muted(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.63, green: 0.61, blue: 0.59) : Color(red: 0.45, green: 0.45, blue: 0.43)
    }
    static func stroke(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color.white.opacity(0.10) : Color.black.opacity(0.07)
    }
}

struct ClaudeMark: View {
    var size: CGFloat = 38
    var color: Color = ClaudeColors.accent

    var body: some View {
        Canvas { context, _ in
            let center = CGPoint(x: size / 2, y: size / 2)
            for index in 0..<12 {
                let angle = CGFloat(index) * .pi / 6 - .pi / 2
                let distance = size * (index.isMultiple(of: 3) ? 0.165 : 0.19)
                let reach = size * (index.isMultiple(of: 2) ? 0.472 : 0.415)
                let spread = size * 0.052
                let tip = CGPoint(x: center.x + cos(angle) * reach, y: center.y + sin(angle) * reach)
                let root = CGPoint(x: center.x + cos(angle) * distance, y: center.y + sin(angle) * distance)
                let perpendicular = CGVector(dx: -sin(angle) * spread, dy: cos(angle) * spread)
                var path = Path()
                path.move(to: CGPoint(x: root.x + perpendicular.dx, y: root.y + perpendicular.dy))
                path.addLine(to: tip)
                path.addLine(to: CGPoint(x: root.x - perpendicular.dx, y: root.y - perpendicular.dy))
                path.closeSubpath()
                context.fill(path, with: .color(color))
            }
            context.fill(Path(ellipseIn: CGRect(x: center.x - size * 0.13, y: center.y - size * 0.13, width: size * 0.26, height: size * 0.26)), with: .color(color))
        }
        .frame(width: size, height: size)
        .accessibilityLabel("Claude-inspired starburst")
    }
}

struct RoundIconButton: View {
    let symbol: String
    var background: Bool = true
    var action: () -> Void
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 17, weight: .regular))
                .frame(width: 42, height: 42)
                .foregroundStyle(ClaudeColors.text(scheme))
                .background(background ? ClaudeColors.surface(scheme) : .clear, in: Circle())
                .overlay(Circle().stroke(background ? ClaudeColors.stroke(scheme) : .clear, lineWidth: 0.7))
        }
        .buttonStyle(.plain)
    }
}

struct SheetHandle: View {
    var body: some View {
        Capsule().fill(.secondary.opacity(0.28)).frame(width: 38, height: 5).padding(.top, 9)
    }
}
