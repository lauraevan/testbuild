import SwiftUI

// Palette measured against public Claude iOS screenshots, not extracted app resources.
enum ClaudeColors {
    static let accent = Color(red: 0.83, green: 0.42, blue: 0.30)
    static let brightBlue = Color(red: 0.20, green: 0.55, blue: 0.98)
    static func background(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.117, green: 0.117, blue: 0.117) : Color(red: 0.989, green: 0.984, blue: 0.973)
    }
    static func sidebar(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.090, green: 0.090, blue: 0.090) : Color(red: 0.964, green: 0.959, blue: 0.945)
    }
    static func surface(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.143, green: 0.143, blue: 0.143) : Color.white
    }
    static func bubble(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.071, green: 0.071, blue: 0.071) : Color(red: 0.938, green: 0.927, blue: 0.908)
    }
    static func text(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.971, green: 0.964, blue: 0.946) : Color(red: 0.185, green: 0.181, blue: 0.166)
    }
    static func muted(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.607, green: 0.607, blue: 0.598) : Color(red: 0.474, green: 0.463, blue: 0.451)
    }
    static func stroke(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color.white.opacity(0.10) : Color.black.opacity(0.085)
    }
    static func elevated(_ scheme: ColorScheme) -> Color {
        scheme == .dark ? Color(red: 0.18, green: 0.18, blue: 0.18) : Color(red: 0.970, green: 0.966, blue: 0.953)
    }
}

struct ClaudeMark: View {
    var size: CGFloat = 38
    var color: Color = ClaudeColors.accent

    var body: some View {
        Canvas { context, _ in
            let center = CGPoint(x: size / 2, y: size / 2)
            // The brand's radial slash motif, redrawn with rounded line segments.
            let lengths: [CGFloat] = [0.46, 0.35, 0.44, 0.37, 0.45, 0.34,
                                      0.45, 0.35, 0.45, 0.36, 0.44, 0.36]
            for ray in 0..<12 {
                let a = CGFloat(ray) * .pi / 6 - .pi / 2
                let inner = size * (ray % 3 == 0 ? 0.092 : 0.145)
                let outer = size * lengths[ray]
                var path = Path()
                path.move(to: CGPoint(x: center.x + cos(a) * inner, y: center.y + sin(a) * inner))
                path.addLine(to: CGPoint(x: center.x + cos(a) * outer, y: center.y + sin(a) * outer))
                context.stroke(path, with: .color(color), style: StrokeStyle(lineWidth: max(1.4, size * 0.067), lineCap: .round))
            }
        }
        .frame(width: size, height: size)
        .accessibilityLabel("Claude starburst")
    }
}

struct RoundIconButton: View {
    let symbol: String
    var background: Bool = true
    var action: () -> Void
    @Environment(\.colorScheme) private var scheme
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 17, weight: .regular))
                .frame(width: 46, height: 46)
                .foregroundStyle(ClaudeColors.text(scheme))
                .background(background ? ClaudeColors.elevated(scheme) : .clear, in: Circle())
                .overlay(Circle().stroke(background ? ClaudeColors.stroke(scheme) : .clear, lineWidth: 0.8))
        }
        .buttonStyle(.plain)
    }
}

struct SheetHandle: View {
    var body: some View {
        Capsule().fill(Color.secondary.opacity(0.5))
            .frame(width: 37, height: 5).padding(.top, 8)
    }
}

struct ClaudeFont {
    static func serif(_ size: CGFloat) -> Font { .custom("Georgia", size: size) }
    static func heading(_ size: CGFloat) -> Font { .custom("Georgia", size: size).weight(.regular) }
}
