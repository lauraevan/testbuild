import Foundation

struct ChatAttachment: Identifiable, Codable, Equatable {
    enum Kind: String, Codable { case image, document }
    var id: UUID = UUID()
    var name: String
    var mimeType: String
    var kind: Kind
    var data: Data?
    var extractedText: String?
}

struct ChatMessage: Identifiable, Codable, Equatable {
    enum Role: String, Codable { case user, assistant }
    var id: UUID = UUID()
    var role: Role
    var text: String
    var createdAt: Date = .now
    var attachments: [ChatAttachment] = []
}

struct Conversation: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var title: String
    var messages: [ChatMessage] = []
    var updatedAt: Date = .now
    var starred: Bool = false
    var incognito: Bool = false
    var projectID: UUID? = nil
}

struct ClaudeProject: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var details: String = ""
    var instructions: String = ""
    var createdAt: Date = .now
}

struct ClaudeModel: Identifiable, Hashable {
    let id: String
    let name: String
    let subtitle: String
    static let all: [ClaudeModel] = [
        .init(id: "claude-opus-5-5", name: "Opus 5.5", subtitle: "Most capable for ambitious work"),
        .init(id: "claude-sonnet-5-5", name: "Sonnet 5.5", subtitle: "Responsive everyday work"),
        .init(id: "claude-haiku-5-5", name: "Haiku 5.5", subtitle: "Fastest, most efficient"),
        .init(id: "claude-fable-5-1", name: "Fable 5.1", subtitle: "For demanding reasoning and long work"),
        .init(id: "claude-sonnet-4-6", name: "Sonnet 4.6", subtitle: "Previous-generation Sonnet")
    ]
    static let defaultModel = all[1]
}

struct SavedArtifact: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var title: String
    var content: String
    var updatedAt: Date = .now
}

struct LocalReminder: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var title: String
    var notes: String = ""
    var scheduledAt: Date
    var repeatsDaily: Bool = false
    var completed: Bool = false
}

enum NavigationDestination: Equatable {
    case chat
    case chats
    case projects
    case project(UUID)
    case artifacts
    case cowork
    case code
    case tasks
    case connectors
    case settings
}
