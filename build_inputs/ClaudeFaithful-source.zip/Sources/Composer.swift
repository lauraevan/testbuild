import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import PDFKit

struct ChatComposer: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @Binding var text: String
    @Binding var attachments: [ChatAttachment]
    var disabled: Bool
    var onSend: () -> Void

    @State private var showTools = false
    @State private var showImporter = false
    @State private var showPhotoLibrary = false
    @State private var photoItem: PhotosPickerItem?
    @State private var showCamera = false
    @State private var showVoice = false
    @FocusState private var focused: Bool

    private var canSend: Bool { !disabled && (!text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !attachments.isEmpty) }

    var body: some View {
        VStack(spacing: 8) {
            VStack(alignment: .leading, spacing: 8) {
                if !attachments.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 7) {
                            ForEach(attachments) { attachment in
                                HStack(spacing: 6) {
                                    Image(systemName: attachment.kind == .image ? "photo" : "doc.text")
                                    Text(attachment.name).lineLimit(1)
                                    Button { attachments.removeAll { $0.id == attachment.id } } label: {
                                        Image(systemName: "xmark.circle.fill")
                                    }
                                }
                                .font(.system(size: 11))
                                .padding(8)
                                .background(ClaudeColors.bubble(scheme), in: RoundedRectangle(cornerRadius: 9))
                            }
                        }
                    }
                }
                TextField("Chat with Claude", text: $text, axis: .vertical)
                    .font(.system(size: 16))
                    .lineLimit(1...6)
                    .focused($focused)
                    .padding(.horizontal, 5)
                    .padding(.top, 8)
                    .submitLabel(.send)
                    .onSubmit { if canSend { onSend() } }
                HStack(spacing: 11) {
                    Button { focused = false; showTools = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 20, weight: .light))
                            .frame(width: 31, height: 31)
                    }
                    .accessibilityLabel("Add files or photos")
                    Button { store.thinkEnabled.toggle() } label: {
                        Image(systemName: "slider.horizontal.3")
                            .font(.system(size: 17))
                            .frame(width: 30, height: 31)
                            .foregroundStyle(store.thinkEnabled ? ClaudeColors.accent : ClaudeColors.muted(scheme))
                    }
                    .accessibilityLabel("Thinking options")
                    if store.webSearchEnabled {
                        Image(systemName: "globe")
                            .font(.system(size: 15)).foregroundStyle(ClaudeColors.accent)
                    }
                    Spacer()
                    Button { focused = false; showVoice = true } label: {
                        Image(systemName: "mic")
                            .font(.system(size: 17))
                            .frame(width: 30, height: 31)
                    }
                    .accessibilityLabel("Voice dictation")
                    Button {
                        if canSend { onSend() }
                        else { focused = false; showVoice = true }
                    } label: {
                        Image(systemName: canSend ? "arrow.up" : "waveform")
                            .font(.system(size: 17, weight: .semibold))
                            .foregroundStyle(canSend ? Color.white : ClaudeColors.text(scheme))
                            .frame(width: 33, height: 33)
                            .background(canSend ? ClaudeColors.accent : ClaudeColors.bubble(scheme), in: Circle())
                    }
                    .disabled(disabled)
                    .accessibilityLabel(canSend ? "Send message" : "Voice mode")
                }
                .foregroundStyle(ClaudeColors.muted(scheme))
            }
            .padding(.horizontal, 12)
            .padding(.top, 8)
            .padding(.bottom, 9)
            .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 21, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 21, style: .continuous)
                .stroke(ClaudeColors.stroke(scheme), lineWidth: 0.9))
            .shadow(color: .black.opacity(scheme == .dark ? 0.08 : 0.025), radius: 6, y: 1)
            if store.isDemoMode {
                Text("Demo mode · Add an API key in Settings for live Claude")
                    .font(.system(size: 10.5))
                    .foregroundStyle(ClaudeColors.muted(scheme))
            }
        }
        .padding(.horizontal, 13)
        .padding(.bottom, 9)
        .confirmationDialog("Add to chat", isPresented: $showTools) {
            Button("Photo Library", systemImage: "photo") { showPhotoLibrary = true }
            Button("Camera", systemImage: "camera") { showCamera = true }
            Button("Choose file", systemImage: "doc") { showImporter = true }
            Button("Cancel", role: .cancel) {}
        }
        .photosPicker(isPresented: $showPhotoLibrary, selection: $photoItem, matching: .images)
        .onChange(of: photoItem) { _, newValue in
            guard let newValue else { return }
            Task {
                if let data = try? await newValue.loadTransferable(type: Data.self),
                   let image = UIImage(data: data),
                   let jpeg = image.jpegData(compressionQuality: 0.8) {
                    attachments.append(ChatAttachment(name: "Photo.jpg", mimeType: "image/jpeg", kind: .image, data: jpeg))
                }
                photoItem = nil
            }
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.image, .pdf, .plainText, .text]) { result in
            guard case .success(let url) = result else { return }
            let granted = url.startAccessingSecurityScopedResource()
            defer { if granted { url.stopAccessingSecurityScopedResource() } }
            guard let bytes = try? Data(contentsOf: url) else { return }
            let ext = url.pathExtension.lowercased()
            if let image = UIImage(data: bytes), let jpeg = image.jpegData(compressionQuality: 0.8) {
                attachments.append(ChatAttachment(name: url.lastPathComponent, mimeType: "image/jpeg", kind: .image, data: jpeg))
            } else if ext == "pdf", let pdf = PDFDocument(data: bytes) {
                attachments.append(ChatAttachment(name: url.lastPathComponent, mimeType: "application/pdf", kind: .document, extractedText: String((pdf.string ?? "").prefix(100_000))))
            } else if let content = String(data: bytes, encoding: .utf8) {
                attachments.append(ChatAttachment(name: url.lastPathComponent, mimeType: "text/plain", kind: .document, extractedText: String(content.prefix(100_000))))
            }
        }
        .sheet(isPresented: $showCamera) {
            CameraPicker { image in
                if let image, let jpeg = image.jpegData(compressionQuality: 0.8) {
                    attachments.append(ChatAttachment(name: "Camera.jpg", mimeType: "image/jpeg", kind: .image, data: jpeg))
                }
            }
            .ignoresSafeArea()
        }
        .sheet(isPresented: $showVoice) {
            VoiceCaptureSheet { transcript in
                if !transcript.isEmpty {
                    text = text.isEmpty ? transcript : text + " " + transcript
                }
            }
            .presentationDetents([.medium])
        }
    }
}

struct CameraPicker: UIViewControllerRepresentable {
    var completion: (UIImage?) -> Void
    @Environment(\.dismiss) private var dismiss

    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let controller = UIImagePickerController()
        controller.sourceType = UIImagePickerController.isSourceTypeAvailable(.camera) ? .camera : .photoLibrary
        controller.delegate = context.coordinator
        return controller
    }
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    final class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: CameraPicker
        init(_ parent: CameraPicker) { self.parent = parent }
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            parent.completion(info[.originalImage] as? UIImage)
            parent.dismiss()
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { parent.dismiss() }
    }
}
