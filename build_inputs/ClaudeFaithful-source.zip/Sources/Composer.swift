import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import PDFKit

struct ChatComposer: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @Binding var text: String
    @Binding var attachments: [ChatAttachment]
    var disabled: Bool
    var openModels: () -> Void
    var onSend: () -> Void

    @State private var showContext = false
    @State private var showImporter = false
    @State private var showPhotoLibrary = false
    @State private var photoItem: PhotosPickerItem?
    @State private var showCamera = false
    @State private var showVoice = false
    @State private var attachmentWarning: String?
    @FocusState private var focused: Bool

    private var canSend: Bool { !disabled && (!text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || !attachments.isEmpty) }

    var body: some View {
        VStack(spacing: 7) {
            if store.activeConversation != nil {
                if !attachments.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(attachments) { attachment in
                                HStack(spacing: 7) {
                                    Image(systemName: attachment.kind == .image ? "photo" : "doc.text")
                                    Text(attachment.name).lineLimit(1)
                                    Button { attachments.removeAll { $0.id == attachment.id } } label: {
                                        Image(systemName: "xmark.circle.fill")
                                    }
                                }
                                .font(.system(size: 12))
                                .padding(9)
                                .background(ClaudeColors.surface(scheme), in: RoundedRectangle(cornerRadius: 10))
                            }
                        }
                    }
                }
                compactComposer
            } else {
            VStack(alignment: .leading, spacing: 9) {
                if !attachments.isEmpty {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(attachments) { attachment in
                                HStack(spacing: 6) {
                                    Image(systemName: attachment.kind == .image ? "photo" : "doc.text")
                                    Text(attachment.name).lineLimit(1)
                                    Button { attachments.removeAll { $0.id == attachment.id } } label: {
                                        Image(systemName: "xmark.circle.fill")
                                    }
                                }
                                .font(.system(size: 12))
                                .padding(10)
                                .background(ClaudeColors.elevated(scheme), in: RoundedRectangle(cornerRadius: 10))
                            }
                        }
                    }
                }
                TextField(store.activeConversation == nil ? "Chat with Claude" : "Reply to Claude", text: $text, axis: .vertical)
                    .font(.system(size: 17))
                    .foregroundStyle(ClaudeColors.text(scheme))
                    .lineLimit(1...7)
                    .focused($focused)
                    .submitLabel(.send)
                    .onSubmit { if canSend { onSend() } }
                    .padding(.horizontal, 6)
                    .padding(.top, 8)
                HStack(spacing: 9) {
                    Button { focused = false; showContext = true } label: {
                        Image(systemName: "plus")
                            .font(.system(size: 21, weight: .regular))
                            .frame(width: 40, height: 40)
                            .foregroundStyle(ClaudeColors.text(scheme))
                            .background(ClaudeColors.elevated(scheme).opacity(0.85), in: Circle())
                    }
                    .accessibilityLabel("Add to chat")
                    Button { focused = false; openModels() } label: {
                        HStack(spacing: 5) {
                            Text(store.selectedModel.name)
                            Image(systemName: "chevron.down")
                                .font(.system(size: 10, weight: .medium))
                        }
                        .font(.system(size: 13))
                        .foregroundStyle(ClaudeColors.text(scheme))
                        .padding(.horizontal, 14)
                        .frame(height: 40)
                        .background(ClaudeColors.elevated(scheme).opacity(0.85), in: Capsule())
                    }
                    .accessibilityLabel("Select model")
                    Spacer(minLength: 0)
                    if !canSend {
                        Button { focused = false; showVoice = true } label: {
                            Image(systemName: "mic")
                                .font(.system(size: 17))
                                .foregroundStyle(ClaudeColors.text(scheme))
                                .frame(width: 39, height: 40)
                                .background(ClaudeColors.elevated(scheme).opacity(0.85), in: Circle())
                        }
                        .accessibilityLabel("Dictate a message")
                    }
                    Button {
                        if canSend { onSend() }
                        else { focused = false; showVoice = true }
                    } label: {
                        Image(systemName: canSend ? "arrow.up" : "waveform")
                            .font(.system(size: canSend ? 18 : 19, weight: .semibold))
                            .foregroundStyle(canSend ? ClaudeColors.bubble(scheme) : ClaudeColors.background(scheme))
                            .frame(width: 40, height: 40)
                            .background(canSend ? ClaudeColors.accent : ClaudeColors.text(scheme), in: Circle())
                    }
                    .disabled(disabled)
                    .accessibilityLabel(canSend ? "Send message" : "Voice chat")
                }
            }
            .padding(.horizontal, 9)
            .padding(.top, 11)
            .padding(.bottom, 8)
            .claudeGlassComposer(radius: 27)
            }
        }
        .padding(.horizontal, 18)
        .padding(.bottom, 11)
        .sheet(isPresented: $showContext) {
            AddContextSheet(openCamera: { showContext = false; showCamera = true },
                            openPhotos: { showContext = false; showPhotoLibrary = true },
                            openFiles: { showContext = false; showImporter = true })
            .presentationDetents([.medium, .large])
            .presentationDragIndicator(.hidden)
        }
        .photosPicker(isPresented: $showPhotoLibrary, selection: $photoItem, matching: .images)
        .onChange(of: photoItem) { _, item in
            guard let item else { return }
            Task {
                if let data = try? await item.loadTransferable(type: Data.self),
                   let photo = UIImage(data: data), let jpeg = photo.jpegData(compressionQuality: 0.78) {
                    attachments.append(ChatAttachment(name: "Photo.jpg", mimeType: "image/jpeg", kind: .image, data: jpeg))
                }
                photoItem = nil
            }
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.image, .pdf, .plainText, .text]) { result in
            guard case .success(let url) = result else { return }
            let allowed = url.startAccessingSecurityScopedResource()
            defer { if allowed { url.stopAccessingSecurityScopedResource() } }
            guard let data = try? Data(contentsOf: url) else {
                attachmentWarning = "This file couldn't be read. Try saving it to Files first."
                return
            }
            if data.count > 12_000_000 {
                attachmentWarning = "Files larger than 12 MB aren't supported in this local app."
            } else if let image = UIImage(data: data), let jpeg = image.jpegData(compressionQuality: 0.80) {
                attachments.append(ChatAttachment(name: url.lastPathComponent, mimeType: "image/jpeg", kind: .image, data: jpeg))
            } else if url.pathExtension.lowercased() == "pdf", let pdf = PDFDocument(data: data) {
                // Keep the original document, not only OCR text, so Claude can analyze its pages visually.
                if pdf.isEncrypted {
                    attachmentWarning = "Password-protected PDFs aren't supported."
                } else {
                    attachments.append(ChatAttachment(name: url.lastPathComponent, mimeType: "application/pdf", kind: .document,
                                                      data: data))
                }
            } else if let content = String(data: data, encoding: .utf8) {
                attachments.append(ChatAttachment(name: url.lastPathComponent, mimeType: "text/plain", kind: .document,
                                                  extractedText: String(content.prefix(100_000))))
            } else {
                attachmentWarning = "This file type isn't supported. Use a PDF, image, or text file."
            }
        }
        .alert("Couldn't attach file", isPresented: Binding(
            get: { attachmentWarning != nil },
            set: { if !$0 { attachmentWarning = nil } }
        )) {
            Button("OK", role: .cancel) { attachmentWarning = nil }
        } message: {
            Text(attachmentWarning ?? "")
        }
        .sheet(isPresented: $showCamera) {
            CameraPicker { photo in
                if let photo, let jpeg = photo.jpegData(compressionQuality: 0.80) {
                    attachments.append(ChatAttachment(name: "Camera.jpg", mimeType: "image/jpeg", kind: .image, data: jpeg))
                }
            }
            .ignoresSafeArea()
        }
        .sheet(isPresented: $showVoice) {
            VoiceCaptureSheet { transcript in
                if !transcript.isEmpty { text = text.isEmpty ? transcript : text + " " + transcript }
            }
            .presentationDetents([.medium])
        }
    }

    private var compactComposer: some View {
        HStack(alignment: .bottom, spacing: 10) {
            Button { focused = false; showContext = true } label: {
                Image(systemName: "plus")
                    .font(.system(size: 21, weight: .regular))
                    .frame(width: 41, height: 41)
                    .foregroundStyle(ClaudeColors.text(scheme))
                    .background(ClaudeColors.elevated(scheme), in: Circle())
            }
            .accessibilityLabel("Add content or select model")
            TextField("Reply or hold to talk", text: $text, axis: .vertical)
                .font(.system(size: 16))
                .lineLimit(1...5)
                .focused($focused)
                .foregroundStyle(ClaudeColors.text(scheme))
                .submitLabel(.send)
                .onSubmit { if canSend { onSend() } }
                .frame(maxWidth: .infinity, minHeight: 41)
                .padding(.leading, 2)
            Button { focused = false; showVoice = true } label: {
                Image(systemName: "mic")
                    .font(.system(size: 19))
                    .foregroundStyle(ClaudeColors.text(scheme))
                    .frame(width: 41, height: 41)
                    .background(ClaudeColors.elevated(scheme), in: Circle())
            }
            .accessibilityLabel("Voice input")
            Button { if canSend { onSend() } else { focused = false; showVoice = true } } label: {
                Image(systemName: "arrow.up")
                    .font(.system(size: 18, weight: .medium))
                    .foregroundStyle(Color.white.opacity(canSend ? 1 : 0.54))
                    .frame(width: 41, height: 41)
                    .background(ClaudeColors.accent.opacity(canSend ? 1 : 0.50), in: Circle())
            }
            .disabled(disabled)
            .accessibilityLabel(canSend ? "Send" : "Start voice input")
        }
        .padding(.horizontal, 9)
        .padding(.vertical, 8)
        .claudeGlassComposer(radius: 100)
    }
}

struct AddContextSheet: View {
    @EnvironmentObject private var store: ChatStore
    @Environment(\.colorScheme) private var scheme
    @Environment(\.dismiss) private var dismiss
    @State private var showStyle = false
    @State private var projectList = false
    @State private var toolInfo = false
    @State private var modelChoice = false
    @AppStorage("claudere-writing-style") private var writingStyle = "Normal"
    var openCamera: () -> Void
    var openPhotos: () -> Void
    var openFiles: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            SheetHandle()
            HStack {
                RoundIconButton(symbol: "xmark") { dismiss() }
                Spacer()
                Text("Add to Chat").font(.system(size: 17, weight: .semibold))
                Spacer()
                Color.clear.frame(width: 46, height: 46)
            }
            .padding(.horizontal, 14)
            HStack(spacing: 9) {
                tile("camera", "Camera", openCamera)
                tile("photo.on.rectangle", "Photos", openPhotos)
                tile("doc.badge.arrow.up", "Files", openFiles)
            }
            .padding(.horizontal, 18)
            .padding(.top, 8)
            .padding(.bottom, 18)
            Rectangle().fill(ClaudeColors.stroke(scheme)).frame(height: 1).padding(.horizontal, 18)
            VStack(spacing: 1) {
                detailRow("cpu", "Model", store.selectedModel.name) { modelChoice = true }
                detailRow("archivebox", "Add to project", store.nextProjectID == nil ? "None" : "Selected") { projectList = true }
                detailRow("pencil.and.outline", "Choose style", writingStyle) { showStyle = true }
                detailRow("briefcase", "Tool access", "Auto") { toolInfo = true }
            }
            Rectangle().fill(ClaudeColors.stroke(scheme)).frame(height: 1).padding(.horizontal, 18)
            Toggle(isOn: $store.webSearchEnabled) {
                Label("Web search", systemImage: "globe")
                    .font(.system(size: 16))
            }
            .tint(ClaudeColors.brightBlue)
            .padding(.horizontal, 26)
            .padding(.vertical, 24)
            Text("Live web search uses the official Claude API tool when an API key is configured. Additional usage may be billed.")
                .font(.system(size: 11))
                .foregroundStyle(ClaudeColors.muted(scheme))
                .padding(.horizontal, 28)
            Spacer(minLength: 0)
        }
        .background(ClaudeColors.background(scheme))
        .alert("Tool access", isPresented: $toolInfo) { Button("OK", role: .cancel) {} } message: {
            Text("When connected, Claude can automatically use enabled server tools such as web search. This recreation does not run your device applications or local code.")
        }
        .confirmationDialog("Choose style", isPresented: $showStyle) {
            ForEach(["Normal", "Concise", "Explanatory", "Formal"], id: \.self) { style in
                Button(style) { writingStyle = style }
            }
        }
        .sheet(isPresented: $modelChoice) { ModelSheet() }
        .sheet(isPresented: $projectList) {
            NavigationStack {
                List {
                    Button("None") {
                        if let id = store.currentID { store.addToProject(id, projectID: nil) }
                        else { store.nextProjectID = nil }
                        projectList = false
                    }
                    ForEach(store.projects) { project in
                        Button(project.name) {
                            if let id = store.currentID { store.addToProject(id, projectID: project.id) }
                            else { store.addToProjectForNextChat(project.id) }
                            projectList = false
                        }
                    }
                }
                .navigationTitle("Add to project")
                .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { projectList = false } } }
            }
            .presentationDetents([.medium])
        }
    }

    private func tile(_ icon: String, _ title: String, _ perform: @escaping () -> Void) -> some View {
        Button(action: perform) {
            VStack(spacing: 9) {
                Image(systemName: icon).font(.system(size: 22, weight: .regular))
                Text(title).font(.system(size: 16))
            }
            .foregroundStyle(ClaudeColors.text(scheme))
            .frame(maxWidth: .infinity)
            .frame(height: 94)
            .background(ClaudeColors.bubble(scheme), in: RoundedRectangle(cornerRadius: 17))
        }
        .buttonStyle(.plain)
    }

    private func detailRow(_ icon: String, _ title: String, _ subtitle: String, _ perform: @escaping () -> Void) -> some View {
        Button(action: perform) {
            HStack(spacing: 12) {
                Image(systemName: icon).font(.system(size: 18)).frame(width: 23)
                Text(title).font(.system(size: 16))
                Spacer(minLength: 5)
                Text(subtitle).font(.system(size: 14)).foregroundStyle(ClaudeColors.muted(scheme))
                Image(systemName: "chevron.right").font(.system(size: 12)).foregroundStyle(ClaudeColors.muted(scheme))
            }
            .foregroundStyle(ClaudeColors.text(scheme))
            .frame(height: 57)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 26)
    }
}

struct CameraPicker: UIViewControllerRepresentable {
    var completion: (UIImage?) -> Void
    @Environment(\.dismiss) private var dismiss

    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let controller = UIImagePickerController()
        controller.sourceType = UIImagePickerController.isSourceTypeAvailable(.camera) ? .camera : .photoLibrary
        controller.delegate = context.coordinator
        return controller
    }
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
    final class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: CameraPicker
        init(_ parent: CameraPicker) { self.parent = parent }
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            parent.completion(info[.originalImage] as? UIImage)
            parent.dismiss()
        }
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) { parent.dismiss() }
    }
}
